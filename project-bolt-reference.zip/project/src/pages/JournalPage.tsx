import { useMemo, useState } from 'react';
import { BookOpen, Plus, Trash2, Save, Target, Eye, CheckSquare, FileText, Calendar } from 'lucide-react';
import { useJournalEntries, useTrades } from '@/hooks/useData';
import { useAuth } from '@/context/AuthContext';
import { formatCurrency, formatPercent } from '@/lib/utils';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { LoadingSpinner, EmptyState } from '@/components/ui/Feedback';
import { Modal } from '@/components/ui/Modal';
import type { JournalEntry, JournalInput, JournalType, ChecklistItem, ReviewPrompt } from '@/lib/types';
import { format, parseISO } from 'date-fns';
import { SuggestInput } from '@/components/ui/SuggestInput';
import { GOAL_SUGGESTIONS, FOCUS_SUGGESTIONS, NOTE_SUGGESTIONS } from '@/lib/suggestions';

const DEFAULT_CHECKLIST: ChecklistItem[] = [
  { label: 'Reviewed higher timeframe trend', checked: false },
  { label: 'Identified key support/resistance levels', checked: false },
  { label: 'Checked economic calendar for news', checked: false },
  { label: 'Defined entry and exit criteria', checked: false },
  { label: 'Set proper position size for risk', checked: false },
  { label: 'No emotional bias or FOMO', checked: false },
];

const DEFAULT_PROMPTS: ReviewPrompt[] = [
  { question: 'Did I follow my trading plan today?', answer: '' },
  { question: 'What was my best decision?', answer: '' },
  { question: 'What was my worst decision?', answer: '' },
  { question: 'How did I manage risk?', answer: '' },
  { question: 'What will I improve tomorrow?', answer: '' },
];

export function JournalPage() {
  const { user } = useAuth();
  const { entries, loading, upsertEntry, deleteEntry } = useJournalEntries(user?.id);
  const { trades } = useTrades(user?.id);
  const [showForm, setShowForm] = useState(false);
  const [editingEntry, setEditingEntry] = useState<JournalEntry | null>(null);
  const [filterType, setFilterType] = useState<JournalType | ''>('');

  const filtered = useMemo(() => {
    return filterType ? entries.filter(e => e.entry_type === filterType) : entries;
  }, [entries, filterType]);

  const handleSave = async (data: JournalInput, id?: string) => {
    await upsertEntry(data, id);
    setShowForm(false);
    setEditingEntry(null);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this journal entry?')) await deleteEntry(id);
  };

  if (loading) return <LoadingSpinner label="Loading journal..." />;

  return (
    <div>
      <SectionHeader
        title="Journal"
        subtitle="Plan your sessions, track goals, and review your performance"
        action={
          <button onClick={() => { setEditingEntry(null); setShowForm(true); }} className="btn-primary">
            <Plus size={18} /> New Entry
          </button>
        }
      />

      {/* Filter */}
      <div className="flex gap-2 mb-4">
        {(['', 'daily', 'weekly', 'monthly'] as const).map(t => (
          <button
            key={t}
            onClick={() => setFilterType(t)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
              filterType === t ? 'bg-brand-500/10 text-brand-600 dark:text-brand-400 border-brand-500/20' : 'bg-secondary border-themed text-secondary hover:border-muted'
            }`}
          >
            {t === '' ? 'All Entries' : t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="card p-8">
          <EmptyState icon={<BookOpen size={40} />} title="No journal entries yet" message="Create a daily, weekly, or monthly journal entry to plan your sessions and reflect on your trading." />
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map(entry => (
            <JournalCard key={entry.id} entry={entry} trades={trades} onEdit={() => { setEditingEntry(entry); setShowForm(true); }} onDelete={() => handleDelete(entry.id)} />
          ))}
        </div>
      )}

      <Modal open={showForm} onClose={() => { setShowForm(false); setEditingEntry(null); }} title={editingEntry ? 'Edit Journal Entry' : 'New Journal Entry'} size="lg">
        <JournalForm initial={editingEntry} onSave={handleSave} onCancel={() => { setShowForm(false); setEditingEntry(null); }} />
      </Modal>
    </div>
  );
}

function JournalCard({ entry, trades, onEdit, onDelete }: { entry: JournalEntry; trades: any[]; onEdit: () => void; onDelete: () => void }) {
  const entryTrades = useMemo(() => {
    const d = parseISO(entry.entry_date);
    return trades.filter(t => {
      const td = parseISO(t.entry_time);
      if (entry.entry_type === 'daily') return format(td, 'yyyy-MM-dd') === format(d, 'yyyy-MM-dd');
      if (entry.entry_type === 'weekly') return format(td, 'yyyy-ww') === format(d, 'yyyy-ww');
      return format(td, 'yyyy-MM') === format(d, 'yyyy-MM');
    });
  }, [entry, trades]);

  const pnl = entryTrades.reduce((s, t) => s + t.pnl, 0);
  const wins = entryTrades.filter((t: any) => t.outcome === 'win').length;
  const winRate = entryTrades.length ? (wins / entryTrades.length) * 100 : 0;
  const checkedCount = (entry.trading_plan_checklist || []).filter(c => c.checked).length;
  const checklistTotal = (entry.trading_plan_checklist || []).length;

  const typeColors: Record<string, string> = {
    daily: 'badge-brand', weekly: 'badge-accent', monthly: 'badge-warning',
  };

  return (
    <div className="card p-5 card-hover">
      <div className="flex items-start justify-between mb-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className={`badge ${typeColors[entry.entry_type]}`}>{entry.entry_type}</span>
            <span className="text-sm font-semibold">{format(parseISO(entry.entry_date), 'MMM d, yyyy')}</span>
          </div>
          {entryTrades.length > 0 && (
            <p className="text-xs text-muted">{entryTrades.length} trades · {formatCurrency(pnl)} · {formatPercent(winRate)} WR</p>
          )}
        </div>
        <div className="flex gap-1">
          <button onClick={onEdit} className="btn-ghost p-1.5"><FileText size={16} /></button>
          <button onClick={onDelete} className="btn-ghost p-1.5 text-error-500 hover:bg-error-500/10"><Trash2 size={16} /></button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {entry.daily_goals && (
          <div>
            <p className="text-xs font-semibold text-secondary mb-1 flex items-center gap-1"><Target size={12} /> Goals</p>
            <p className="text-sm">{entry.daily_goals}</p>
          </div>
        )}
        {entry.weekly_focus && (
          <div>
            <p className="text-xs font-semibold text-secondary mb-1 flex items-center gap-1"><Eye size={12} /> Focus Area</p>
            <p className="text-sm">{entry.weekly_focus}</p>
          </div>
        )}
        {entry.pre_market_notes && (
          <div>
            <p className="text-xs font-semibold text-secondary mb-1 flex items-center gap-1"><Calendar size={12} /> Pre-Market Notes</p>
            <p className="text-sm">{entry.pre_market_notes}</p>
          </div>
        )}
        {entry.post_session_review && (
          <div>
            <p className="text-xs font-semibold text-secondary mb-1 flex items-center gap-1"><Eye size={12} /> Post-Session Review</p>
            <p className="text-sm">{entry.post_session_review}</p>
          </div>
        )}
      </div>

      {entry.trading_plan_checklist && entry.trading_plan_checklist.length > 0 && (
        <div className="mt-3">
          <p className="text-xs font-semibold text-secondary mb-1.5 flex items-center gap-1"><CheckSquare size={12} /> Trading Plan Checklist ({checkedCount}/{checklistTotal})</p>
          <div className="flex flex-wrap gap-1.5">
            {entry.trading_plan_checklist.map((c, i) => (
              <span key={i} className={`badge text-[10px] ${c.checked ? 'badge-success' : 'badge-neutral'}`}>
                {c.checked ? '✓' : '○'} {c.label}
              </span>
            ))}
          </div>
        </div>
      )}

      {entry.review_prompts && entry.review_prompts.some(p => p.answer) && (
        <div className="mt-3 space-y-1.5">
          {entry.review_prompts.filter(p => p.answer).map((p, i) => (
            <div key={i} className="text-sm">
              <span className="text-xs font-semibold text-secondary">Q: {p.question}</span>
              <p className="mt-0.5">{p.answer}</p>
            </div>
          ))}
        </div>
      )}

      {entry.notes && <p className="mt-3 text-sm text-secondary">{entry.notes}</p>}
    </div>
  );
}

function JournalForm({ initial, onSave, onCancel }: { initial: JournalEntry | null; onSave: (data: JournalInput, id?: string) => void; onCancel: () => void }) {
  const [date, setDate] = useState(initial?.entry_date || format(new Date(), 'yyyy-MM-dd'));
  const [type, setType] = useState<JournalType>(initial?.entry_type || 'daily');
  const [dailyGoals, setDailyGoals] = useState(initial?.daily_goals || '');
  const [weeklyFocus, setWeeklyFocus] = useState(initial?.weekly_focus || '');
  const [preMarket, setPreMarket] = useState(initial?.pre_market_notes || '');
  const [postSession, setPostSession] = useState(initial?.post_session_review || '');
  const [checklist, setChecklist] = useState<ChecklistItem[]>(initial?.trading_plan_checklist || DEFAULT_CHECKLIST);
  const [prompts, setPrompts] = useState<ReviewPrompt[]>(initial?.review_prompts || DEFAULT_PROMPTS);
  const [mood, setMood] = useState(initial?.mood || '');
  const [notes, setNotes] = useState(initial?.notes || '');
  const [saving, setSaving] = useState(false);

  const toggleChecklist = (i: number) => {
    setChecklist(c => c.map((item, idx) => idx === i ? { ...item, checked: !item.checked } : item));
  };

  const updatePrompt = (i: number, answer: string) => {
    setPrompts(p => p.map((item, idx) => idx === i ? { ...item, answer } : item));
  };

  const handleSave = async () => {
    setSaving(true);
    await onSave({
      entry_date: date,
      entry_type: type,
      daily_goals: dailyGoals || null,
      weekly_focus: weeklyFocus || null,
      pre_market_notes: preMarket || null,
      post_session_review: postSession || null,
      trading_plan_checklist: checklist,
      review_prompts: prompts,
      mood: mood || null,
      notes: notes || null,
    }, initial?.id);
    setSaving(false);
  };

  const inputCls = 'input-field';
  const labelCls = 'block text-xs font-semibold text-secondary mb-1.5';

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className={labelCls}>Date</label>
          <input type="date" className={inputCls} value={date} onChange={e => setDate(e.target.value)} />
        </div>
        <div>
          <label className={labelCls}>Entry Type</label>
          <select className={inputCls} value={type} onChange={e => setType(e.target.value as JournalType)}>
            <option value="daily">Daily</option>
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className={labelCls}>Daily Goals</label>
          <SuggestInput multiline rows={2} value={dailyGoals} onChange={setDailyGoals} placeholder="What do you want to achieve today?" suggestions={GOAL_SUGGESTIONS} />
        </div>
        <div>
          <label className={labelCls}>Weekly / Monthly Focus</label>
          <SuggestInput multiline rows={2} value={weeklyFocus} onChange={setWeeklyFocus} placeholder="Patience, discipline, risk management..." suggestions={FOCUS_SUGGESTIONS} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className={labelCls}>Pre-Market Preparation</label>
          <SuggestInput multiline rows={3} value={preMarket} onChange={setPreMarket} placeholder="Market overview, key levels, news events..." suggestions={NOTE_SUGGESTIONS} />
        </div>
        <div>
          <label className={labelCls}>Post-Session Review</label>
          <SuggestInput multiline rows={3} value={postSession} onChange={setPostSession} placeholder="How did the session go? What went well or poorly?" suggestions={NOTE_SUGGESTIONS} />
        </div>
      </div>

      <div>
        <label className={labelCls}>Trading Plan Checklist</label>
        <div className="space-y-1.5">
          {checklist.map((c, i) => (
            <button key={i} onClick={() => toggleChecklist(i)} className="flex items-center gap-2 w-full p-2 rounded-lg hover:bg-secondary transition-colors text-left">
              <span className={`w-5 h-5 rounded border flex items-center justify-center transition-all ${c.checked ? 'bg-success-500 border-success-500 text-white' : 'border-themed'}`}>
                {c.checked && '✓'}
              </span>
              <span className="text-sm">{c.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className={labelCls}>Review Prompts</label>
        <div className="space-y-2">
          {prompts.map((p, i) => (
            <div key={i}>
              <p className="text-sm font-medium mb-1">{p.question}</p>
              <textarea className={inputCls} rows={1} placeholder="Your answer..." value={p.answer} onChange={e => updatePrompt(i, e.target.value)} />
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className={labelCls}>Mood</label>
          <input className={inputCls} placeholder="Calm, motivated, stressed..." value={mood} onChange={e => setMood(e.target.value)} />
        </div>
      </div>

      <div>
        <label className={labelCls}>Additional Notes</label>
        <SuggestInput multiline rows={2} value={notes} onChange={setNotes} placeholder="Any other thoughts..." suggestions={NOTE_SUGGESTIONS} />
      </div>

      <div className="flex justify-end gap-3 pt-2 border-t border-themed">
        <button onClick={onCancel} className="btn-secondary">Cancel</button>
        <button onClick={handleSave} disabled={saving} className="btn-primary">
          <Save size={18} /> {saving ? 'Saving...' : 'Save Entry'}
        </button>
      </div>
    </div>
  );
}
