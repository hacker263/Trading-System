import { useMemo, useState, useEffect } from 'react';
import { Wallet, Target, TrendingUp, Flame, Activity, Plus, ArrowUpRight, ArrowDownRight, Minus, Star, Clock } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from 'recharts';
import { useTrades } from '@/hooks/useData';
import { useAuth } from '@/context/AuthContext';
import { computeDashboardStats, equityCurveData, dailyPnlData, formatCurrency, formatPercent, formatDateTime, groupByPair } from '@/lib/utils';
import { StatCard } from '@/components/ui/StatCard';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { LoadingSpinner, EmptyState } from '@/components/ui/Feedback';
import { Modal } from '@/components/ui/Modal';
import { TradeForm } from '@/components/TradeForm';
import { TradeCalculator } from '@/components/TradeCalculator';
import { ActivityHeatmap } from '@/components/ActivityHeatmap';
import { Achievements } from '@/components/Achievements';
import { MoodTracker } from '@/components/MoodTracker';
import { StrategyEdgeScore } from '@/components/StrategyEdgeScore';
import { RiskGuardian } from '@/components/RiskGuardian';
import { RiskSettingsModal } from '@/components/RiskSettingsModal';
import { useRiskSettings, useChecklist } from '@/hooks/useData';
import type { TradeInput, RiskSettingsInput } from '@/lib/types';
import { subDays, format } from 'date-fns';

export function DashboardPage({ quickAdd, onQuickAddClose }: { quickAdd?: boolean; onQuickAddClose?: () => void }) {
  const { user } = useAuth();
  const { trades, loading, addTrade } = useTrades(user?.id);
  const { settings, saveSettings } = useRiskSettings(user?.id);
  const { checklist, addChecklistItem, deleteChecklistItem } = useChecklist(user?.id);
  const [showAdd, setShowAdd] = useState(false);
  const [showRiskSettings, setShowRiskSettings] = useState(false);

  useEffect(() => {
    if (quickAdd) {
      setShowAdd(true);
      onQuickAddClose?.();
    }
  }, [quickAdd, onQuickAddClose]);

  const stats = useMemo(() => computeDashboardStats(trades), [trades]);
  const equity = useMemo(() => equityCurveData(trades), [trades]);

  const last7Days = useMemo(() => {
    const end = new Date();
    const start = subDays(end, 6);
    const days: Date[] = [];
    for (let d = start; d <= end; d = new Date(d.getTime() + 86400000)) days.push(d);
    return dailyPnlData(trades, days);
  }, [trades]);

  const topPairs = useMemo(() => groupByPair(trades).slice(0, 5), [trades]);
  const recentTrades = useMemo(() => trades.slice(0, 6), [trades]);

  const handleSubmit = async (data: TradeInput) => {
    await addTrade(data);
    setShowAdd(false);
  };

  const handleSaveRiskSettings = async (input: RiskSettingsInput) => {
    await saveSettings(input);
  };

  if (loading) return <LoadingSpinner label="Loading your dashboard..." />;

  return (
    <div>
      <SectionHeader
        title="Dashboard"
        subtitle="Your trading performance at a glance"
        action={
          <button onClick={() => setShowAdd(true)} className="btn-primary">
            <Plus size={18} /> Add Trade
          </button>
        }
      />

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard
          label="Net P&L"
          value={formatCurrency(stats.totalPnl)}
          icon={<Wallet size={20} className="text-orange-500" />}
          trend={stats.totalPnl >= 0 ? 'up' : 'down'}
          trendValue={`${stats.totalTrades} trades`}
          accent="blue"
        />
        <StatCard
          label="Win Rate"
          value={formatPercent(stats.winRate)}
          icon={<Target size={20} className="text-amber-500" />}
          sublabel={`${stats.wins}W · ${stats.losses}L · ${stats.breakevens}BE`}
          accent="amber"
        />
        <StatCard
          label="Avg Win"
          value={formatCurrency(stats.avgWin)}
          icon={<TrendingUp size={20} className="text-success-500" />}
          sublabel={`Avg Loss: ${formatCurrency(stats.avgLoss)}`}
          accent="emerald"
        />
        <StatCard
          label="Profit Factor"
          value={stats.profitFactor === Infinity ? '∞' : stats.profitFactor.toFixed(2)}
          icon={<Activity size={20} className="text-orange-500" />}
          sublabel={`Expectancy: ${formatCurrency(stats.expectancy)}`}
          accent="blue"
        />
      </div>

      {/* Streak + consecutive */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard
          label="Current Streak"
          value={stats.currentStreak.type === 'none' ? '—' : `${stats.currentStreak.count} ${stats.currentStreak.type === 'win' ? 'Wins' : 'Losses'}`}
          icon={<Flame size={20} className={stats.currentStreak.type === 'win' ? 'text-success-500' : stats.currentStreak.type === 'loss' ? 'text-error-500' : 'text-muted'} />}
          accent={stats.currentStreak.type === 'loss' ? 'rose' : 'amber'}
        />
        <StatCard
          label="Max Consecutive Wins"
          value={String(stats.maxConsecutiveWins)}
          icon={<ArrowUpRight size={20} className="text-success-500" />}
          accent="emerald"
        />
        <StatCard
          label="Max Consecutive Losses"
          value={String(stats.maxConsecutiveLosses)}
          icon={<ArrowDownRight size={20} className="text-error-500" />}
          accent="rose"
        />
        <StatCard
          label="Avg Risk : Reward"
          value={stats.avgRiskReward > 0 ? `1:${stats.avgRiskReward.toFixed(2)}` : '—'}
          icon={<Star size={20} className="text-amber-500" />}
          accent="amber"
        />
      </div>

      {/* Risk Guardian */}
      <div className="mb-6">
        <RiskGuardian trades={trades} settings={settings} onConfigure={() => setShowRiskSettings(true)} />
      </div>

      {/* Trade Calculator */}
      <div className="mb-6">
        <TradeCalculator />
      </div>

      {/* Equity curve + Daily P&L */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <div className="card p-5 lg:col-span-2">
          <h3 className="text-sm font-semibold mb-4">Equity Curve</h3>
          {equity.length > 0 ? (
            <ResponsiveContainer width="100%" height={280}>
              <AreaChart data={equity} margin={{ left: -10, right: 10, top: 5, bottom: 0 }}>
                <defs>
                  <linearGradient id="equityGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#f97316" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#f97316" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} width={50} tickFormatter={(v) => `$${v}`} />
                <Tooltip
                  contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 12, fontSize: 12 }}
                  formatter={(v: any) => [formatCurrency(Number(v)), 'Equity']}
                />
                <Area type="monotone" dataKey="equity" stroke="#f97316" strokeWidth={2} fill="url(#equityGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <EmptyState icon={<TrendingUp size={40} />} title="No equity data yet" message="Add your first trade to see your equity curve grow over time." />
          )}
        </div>

        <div className="card p-5">
          <h3 className="text-sm font-semibold mb-4">Last 7 Days P&L</h3>
          {last7Days.some(d => d.trades > 0) ? (
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={last7Days} margin={{ left: -10, right: 10, top: 5, bottom: 0 }}>
                <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} width={50} tickFormatter={(v) => `$${v}`} />
                <Tooltip
                  contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 12, fontSize: 12 }}
                  formatter={(v: any, _name: any, p: any) => [formatCurrency(Number(v)), `P&L (${(p.payload as any).trades} trades)`]}
                />
                <Bar dataKey="pnl" radius={[6, 6, 0, 0]}>
                  {last7Days.map((d, i) => (
                    <Cell key={i} fill={d.pnl >= 0 ? '#10b981' : '#f87171'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <EmptyState icon={<Activity size={40} />} title="No recent activity" message="Your daily P&L will appear here once you start logging trades." />
          )}
        </div>
      </div>

      {/* Best/Worst day + Top pairs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        <div className="card p-5">
          <h3 className="text-sm font-semibold mb-4">Best & Worst Days</h3>
          <div className="space-y-3">
            {stats.bestDay ? (
              <div className="flex items-center justify-between p-3 rounded-xl bg-success-500/5 border border-success-500/15">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-success-500/10">
                    <ArrowUpRight size={18} className="text-success-500" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">Best Day</p>
                    <p className="text-xs text-muted">{format(new Date(stats.bestDay.date), 'EEE, MMM d yyyy')}</p>
                  </div>
                </div>
                <span className="text-lg font-bold font-mono text-success-500">{formatCurrency(stats.bestDay.pnl)}</span>
              </div>
            ) : <p className="text-sm text-muted">No data yet.</p>}
            {stats.worstDay ? (
              <div className="flex items-center justify-between p-3 rounded-xl bg-error-500/5 border border-error-500/15">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-error-500/10">
                    <ArrowDownRight size={18} className="text-error-500" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">Worst Day</p>
                    <p className="text-xs text-muted">{format(new Date(stats.worstDay.date), 'EEE, MMM d yyyy')}</p>
                  </div>
                </div>
                <span className="text-lg font-bold font-mono text-error-500">{formatCurrency(stats.worstDay.pnl)}</span>
              </div>
            ) : null}
          </div>
        </div>

        <div className="card p-5">
          <h3 className="text-sm font-semibold mb-4">Top Currency Pairs</h3>
          {topPairs.length > 0 ? (
            <div className="space-y-2">
              {topPairs.map(p => (
                <div key={p.pair} className="flex items-center justify-between p-2.5 rounded-lg hover:bg-secondary transition-colors">
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-mono font-semibold">{p.pair}</span>
                    <span className="text-xs text-muted">{p.trades} trades</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-muted">{formatPercent(p.winRate)} WR</span>
                    <span className={`text-sm font-mono font-semibold ${p.pnl >= 0 ? 'text-success-500' : 'text-error-500'}`}>
                      {formatCurrency(p.pnl)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <EmptyState icon={<Wallet size={36} />} title="No pairs tracked yet" message="Your most-traded pairs will show up here." />
          )}
        </div>
      </div>

      {/* Activity Heatmap */}
      <div className="mb-6">
        <ActivityHeatmap trades={trades} />
      </div>

      {/* Achievements + Mood Tracker */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        <Achievements trades={trades} />
        <MoodTracker trades={trades} />
      </div>

      {/* Strategy Edge Scores */}
      <div className="mb-6">
        <StrategyEdgeScore trades={trades} />
      </div>

      {/* Recent trades */}
      <div className="card p-5">
        <h3 className="text-sm font-semibold mb-4">Recent Trades</h3>
        {recentTrades.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-muted uppercase tracking-wide border-b border-themed">
                  <th className="text-left py-2 px-2 font-medium">Date</th>
                  <th className="text-left py-2 px-2 font-medium">Pair</th>
                  <th className="text-left py-2 px-2 font-medium">Dir</th>
                  <th className="text-left py-2 px-2 font-medium">Outcome</th>
                  <th className="text-right py-2 px-2 font-medium">P&L</th>
                  <th className="text-right py-2 px-2 font-medium">Pips</th>
                </tr>
              </thead>
              <tbody>
                {recentTrades.map(t => (
                  <tr key={t.id} className="border-b border-themed/50 hover:bg-secondary transition-colors">
                    <td className="py-2.5 px-2 text-xs text-muted">{formatDateTime(t.entry_time)}</td>
                    <td className="py-2.5 px-2 font-mono font-semibold">{t.pair}</td>
                    <td className="py-2.5 px-2">
                      <span className={`badge ${t.direction === 'long' ? 'badge-success' : 'badge-error'}`}>
                        {t.direction === 'long' ? 'Long' : 'Short'}
                      </span>
                    </td>
                    <td className="py-2.5 px-2">
                      {t.status === 'open' ? (
                        <span className="badge bg-orange-500/10 text-orange-600 dark:text-orange-400 border border-orange-500/20">
                          <Clock size={12} /> Open
                        </span>
                      ) : (
                        <span className={`badge ${t.outcome === 'win' ? 'badge-success' : t.outcome === 'loss' ? 'badge-error' : 'badge-neutral'}`}>
                          {t.outcome === 'win' ? <ArrowUpRight size={12} /> : t.outcome === 'loss' ? <ArrowDownRight size={12} /> : <Minus size={12} />}
                          {t.outcome || '—'}
                        </span>
                      )}
                    </td>
                    <td className={`py-2.5 px-2 text-right font-mono font-semibold ${t.status === 'open' ? 'text-orange-500' : t.pnl >= 0 ? 'text-success-500' : 'text-error-500'}`}>
                      {t.status === 'open' ? 'Pending' : formatCurrency(t.pnl)}
                    </td>
                    <td className="py-2.5 px-2 text-right font-mono text-muted">{t.pips?.toFixed(1) || '0.0'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState icon={<Plus size={36} />} title="No trades yet" message="Click 'Add Trade' to log your first trade and start building your journal." />
        )}
      </div>

      <Modal open={showAdd} onClose={() => setShowAdd(false)} title="Add New Trade" size="lg">
        <TradeForm onSubmit={handleSubmit} onCancel={() => setShowAdd(false)} />
      </Modal>

      <RiskSettingsModal
        open={showRiskSettings}
        onClose={() => setShowRiskSettings(false)}
        settings={settings}
        checklist={checklist}
        onSaveSettings={handleSaveRiskSettings}
        onAddChecklistItem={addChecklistItem}
        onDeleteChecklistItem={deleteChecklistItem}
      />
    </div>
  );
}
