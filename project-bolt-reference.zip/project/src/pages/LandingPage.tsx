import { useEffect, useRef, useState } from 'react';
import {
  TrendingUp, BarChart3, BookOpen, Sparkles, Calendar, Target,
  Flame, Shield, ArrowRight, Users, Zap, LineChart, Award,
  CheckCircle2, Star, ChevronRight, Activity, PenLine, Brain,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

function useScrollReveal() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );
    el.querySelectorAll('[data-reveal]').forEach(child => observer.observe(child));
    return () => observer.disconnect();
  }, []);
  return ref;
}

export function LandingPage({ onEnter }: { onEnter: () => void }) {
  const { session } = useAuth();
  const [scrollY, setScrollY] = useState(0);
  const heroRef = useRef<HTMLDivElement>(null);
  const pageRef = useScrollReveal();

  useEffect(() => {
    const handler = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handler, { passive: true });
    return () => window.removeEventListener('scroll', handler);
  }, []);

  const parallax = (offset: number) => `translateY(${scrollY * offset}px)`;

  const handleTilt = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = e.currentTarget;
    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateX = ((y - centerY) / centerY) * -6;
    const rotateY = ((x - centerX) / centerX) * 6;
    card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-4px)`;
  };

  const resetTilt = (e: React.MouseEvent<HTMLDivElement>) => {
    e.currentTarget.style.transform = '';
  };

  const features = [
    { icon: BarChart3, title: 'Deep Analytics', desc: 'Track P&L, win rate, profit factor, expectancy, and streaks across every currency pair and session.', color: 'from-orange-500 to-amber-600' },
    { icon: BookOpen, title: 'Smart Journaling', desc: 'Pre-market checklists, post-session reviews, mood tracking, and voice notes for every trade.', color: 'from-amber-500 to-orange-600' },
    { icon: Sparkles, title: 'AI Pattern Detection', desc: 'Automatic analysis of your trading habits — find your edge and expose your blind spots.', color: 'from-red-500 to-orange-600' },
    { icon: Calendar, title: 'Calendar View', desc: 'See your trading activity as a heatmap. Spot overtrading days and gaps in your routine.', color: 'from-orange-600 to-red-600' },
    { icon: Target, title: 'Trade Calculator', desc: 'Calculate position size, risk-to-reward, and potential P&L before you enter the market.', color: 'from-yellow-500 to-amber-600' },
    { icon: Flame, title: 'Streak Tracking', desc: 'Monitor your current win/loss streaks and build discipline through visible momentum.', color: 'from-orange-500 to-red-500' },
  ];

  const accountabilityFeatures = [
    { icon: Users, title: 'Shared Visibility', desc: 'Your friend sees your trades. You see theirs. No hiding, no fudging numbers — just honesty.' },
    { icon: Shield, title: 'Zero Pressure', desc: "This isn't a competition. Nobody wins by making the other feel bad. It's about showing up and being real." },
    { icon: PenLine, title: 'Forced Reflection', desc: 'Every trade gets a journal entry. Every loss gets a lesson. Every win gets checked for luck vs skill.' },
    { icon: Brain, title: 'Shared Learning', desc: 'See what works for your partner. Adapt what helps. Discard what doesn\'t. Grow on each other\'s shoulders.' },
  ];

  const stats = [
    { value: '9', label: 'Analytics Dimensions', suffix: '+' },
    { value: '100', label: 'Journal Privacy', suffix: '%' },
    { value: '24/7', label: 'AI Insights', suffix: '' },
    { value: '0', label: 'Ego Required', suffix: '' },
  ];

  const tickerItems = [
    'EUR/USD +142 pips', 'GBP/JPY -38 pips', 'XAU/USD +560 pips',
    'AUD/CAD +22 pips', 'USD/CHF -15 pips', 'NZD/USD +67 pips',
    'EUR/GBP +11 pips', 'BTC/USD +890 pips', 'US30 +120 pts',
    'NAS100 -45 pts', 'SPX500 +32 pts', 'ETH/USD +210 pips',
  ];

  return (
    <div ref={pageRef} className="min-h-screen bg-primary overflow-x-hidden">
      {/* ─── NAV ─── */}
      <nav className="fixed top-0 left-0 right-0 z-50 px-4 sm:px-6 py-3 transition-all duration-300"
        style={{
          backgroundColor: scrollY > 40 ? 'var(--glass-bg)' : 'transparent',
          backdropFilter: scrollY > 40 ? 'blur(20px) saturate(180%)' : 'none',
          borderBottom: scrollY > 40 ? '1px solid var(--border)' : '1px solid transparent',
        }}
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-gradient-to-br from-orange-500 to-orange-700 text-white shadow-lg shadow-orange-500/20">
              <TrendingUp size={22} />
            </div>
            <span className="font-bold text-base tracking-tight">TradeJournal Pro</span>
          </div>
          <div className="hidden md:flex items-center gap-1">
            <a href="#features" className="btn-ghost text-sm">Features</a>
            <a href="#accountability" className="btn-ghost text-sm">Accountability</a>
            <a href="#how" className="btn-ghost text-sm">How It Works</a>
          </div>
          <button onClick={onEnter} className="btn-primary text-sm">
            {session ? 'Open Dashboard' : 'Get Started'}
            <ArrowRight size={16} />
          </button>
        </div>
      </nav>

      {/* ─── HERO ─── */}
      <section ref={heroRef} className="relative min-h-screen flex items-center justify-center pt-20 pb-12 px-4">
        {/* Animated background orbs */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] rounded-full bg-orange-500/10 blur-[120px] animate-drift" />
          <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] rounded-full bg-amber-500/8 blur-[100px] animate-float-slow" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-red-500/5 blur-[140px] animate-pulse-glow" />
        </div>

        {/* Grid pattern */}
        <div className="absolute inset-0 opacity-[0.04] pointer-events-none" style={{
          backgroundImage: 'linear-gradient(currentColor 1px, transparent 1px), linear-gradient(90deg, currentColor 1px, transparent 1px)',
          backgroundSize: '60px 60px',
          color: 'var(--text-primary)',
        }} />

        <div className="relative z-10 max-w-5xl mx-auto text-center" style={{ transform: parallax(0.15) }}>
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/20 mb-8 animate-slide-up">
            <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
            <span className="text-xs font-semibold text-orange-600 dark:text-orange-400">Built for accountability, not competition</span>
          </div>

          {/* Headline */}
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight leading-[1.05] animate-slide-up" style={{ animationDelay: '0.05s' }}>
            Trade with
            <br />
            <span className="text-gradient animate-gradient-shift" style={{ backgroundSize: '200% auto' }}>radical honesty.</span>
          </h1>

          {/* Subheadline */}
          <p className="mt-6 text-lg sm:text-xl text-secondary max-w-2xl mx-auto leading-relaxed animate-slide-up" style={{ animationDelay: '0.1s' }}>
            A trading journal built for two. Log every trade, review every decision,
            and hold each other accountable — without the pressure of a leaderboard.
          </p>

          {/* CTAs */}
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-3 animate-slide-up" style={{ animationDelay: '0.15s' }}>
            <button onClick={onEnter} className="btn-primary text-base px-6 py-3">
              {session ? 'Open Your Journal' : 'Start Journaling'}
              <ArrowRight size={18} />
            </button>
            <a href="#features" className="btn-secondary text-base px-6 py-3">
              Explore Features
              <ChevronRight size={18} />
            </a>
          </div>

          {/* Trust line */}
          <div className="mt-8 flex items-center justify-center gap-6 text-xs text-muted animate-fade-in" style={{ animationDelay: '0.3s' }}>
            <span className="flex items-center gap-1.5"><Shield size={14} /> Private & secure</span>
            <span className="flex items-center gap-1.5"><Zap size={14} /> Real-time sync</span>
            <span className="flex items-center gap-1.5"><Brain size={14} /> AI-powered</span>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-float">
          <div className="w-6 h-10 rounded-full border-2 border-muted/30 flex items-start justify-center p-1.5">
            <div className="w-1 h-2 rounded-full bg-orange-500 animate-pulse" />
          </div>
        </div>
      </section>

      {/* ─── TICKER ─── */}
      <section className="relative py-4 border-y border-themed bg-secondary/50 overflow-hidden">
        <div className="flex gap-8 animate-ticker whitespace-nowrap">
          {[...tickerItems, ...tickerItems].map((item, i) => (
            <span key={i} className="text-sm font-mono font-medium text-muted flex items-center gap-2">
              {item.includes('+') ? <TrendingUp size={14} className="text-success-500" /> :
               item.includes('-') ? <Activity size={14} className="text-error-500" /> :
               <LineChart size={14} className="text-orange-500" />}
              {item}
            </span>
          ))}
        </div>
      </section>

      {/* ─── STATS ─── */}
      <section className="py-16 px-4">
        <div className="max-w-5xl mx-auto grid grid-cols-2 lg:grid-cols-4 gap-6" data-reveal>
          {stats.map((s, i) => (
            <div key={i} className="text-center">
              <p className="text-4xl lg:text-5xl font-extrabold text-gradient">{s.value}{s.suffix}</p>
              <p className="mt-2 text-sm text-muted">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ─── FEATURES ─── */}
      <section id="features" className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <p className="text-xs font-bold uppercase tracking-wider text-orange-500 mb-3">Everything you need</p>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">A complete trading journal</h2>
            <p className="mt-3 text-secondary max-w-xl mx-auto">From pre-market prep to post-session review, every tool you need to trade with intention.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f, i) => (
              <div
                key={i}
                data-reveal
                className="card card-hover p-6 group"
                onMouseMove={handleTilt}
                onMouseLeave={resetTilt}
                style={{ transformStyle: 'preserve-3d', transition: 'opacity 0.7s ease, transform 0.3s ease, filter 0.7s ease' }}
              >
                <div className={`p-3 rounded-2xl bg-gradient-to-br ${f.color} text-white mb-4 inline-flex shadow-lg group-hover:scale-110 transition-transform duration-200`}>
                  <f.icon size={24} />
                </div>
                <h3 className="font-bold text-base mb-2">{f.title}</h3>
                <p className="text-sm text-secondary leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── ACCOUNTABILITY ─── */}
      <section id="accountability" className="py-20 px-4 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-0 w-96 h-96 rounded-full bg-orange-500/5 blur-3xl" />
          <div className="absolute bottom-0 right-0 w-96 h-96 rounded-full bg-amber-500/5 blur-3xl" />
        </div>
        <div className="relative max-w-5xl mx-auto" data-reveal>
          <div className="text-center mb-14">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/20 mb-4">
              <Users size={14} className="text-orange-500" />
              <span className="text-xs font-semibold text-orange-600 dark:text-orange-400">Why two traders?</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight max-w-2xl mx-auto">
              Accountability beats isolation.
              <br />
              <span className="text-gradient">Ego kills accounts.</span>
            </h2>
            <p className="mt-4 text-secondary max-w-xl mx-auto leading-relaxed">
              Trading alone makes it easy to lie to yourself. Trading with a partner makes it
              harder to hide — and easier to grow. This isn't about who's better. It's about
              showing up, being honest, and not making bad decisions because someone else had a
              better week.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {accountabilityFeatures.map((f, i) => (
              <div key={i} data-reveal className="card card-hover p-6 flex gap-4">
                <div className="flex-shrink-0 p-2.5 rounded-xl bg-orange-500/10 text-orange-500">
                  <f.icon size={22} />
                </div>
                <div>
                  <h3 className="font-bold text-sm mb-1.5">{f.title}</h3>
                  <p className="text-sm text-secondary leading-relaxed">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Quote card */}
          <div className="mt-10 card-gradient p-8 sm:p-10 text-center relative overflow-hidden">
            <div className="absolute top-4 left-4 text-6xl font-serif text-orange-500/20">"</div>
            <div className="absolute bottom-4 right-4 text-6xl font-serif text-orange-500/20 rotate-180">"</div>
            <p className="text-xl sm:text-2xl font-semibold leading-relaxed max-w-2xl mx-auto">
              The goal isn't to beat your partner. The goal is to be better than
              <span className="text-gradient"> yesterday's version of you</span> — with someone who keeps you honest.
            </p>
          </div>
        </div>
      </section>

      {/* ─── HOW IT WORKS ─── */}
      <section id="how" className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-14">
            <p className="text-xs font-bold uppercase tracking-wider text-orange-500 mb-3">Simple workflow</p>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">How it works</h2>
          </div>
          <div className="space-y-4">
            {[
              { step: '01', icon: PenLine, title: 'Log your trades', desc: 'Enter your pair, direction, entry/exit, P&L, pips, and screenshots. Takes 30 seconds.' },
              { step: '02', icon: BookOpen, title: 'Journal every decision', desc: 'Pre-market checklist, session review, mood, and voice notes. Why did you take the trade?' },
              { step: '03', icon: Sparkles, title: 'Get AI insights', desc: 'Automatic pattern detection highlights your edge, your leaks, and your emotional blind spots.' },
              { step: '04', icon: Users, title: 'Review together', desc: 'See your partner\'s trades and journal. Learn from their wins. Avoid their mistakes. Repeat.' },
            ].map((s, i) => (
              <div key={i} data-reveal className="card p-5 flex items-center gap-5 group hover:border-orange-500/30 transition-colors">
                <div className="flex-shrink-0 w-14 h-14 rounded-2xl bg-gradient-to-br from-orange-500 to-orange-700 text-white flex items-center justify-center font-bold text-lg shadow-lg shadow-orange-500/20 group-hover:scale-110 transition-transform">
                  {s.step}
                </div>
                <div className="flex-shrink-0 hidden sm:block">
                  <s.icon size={28} className="text-orange-500" />
                </div>
                <div>
                  <h3 className="font-bold text-base">{s.title}</h3>
                  <p className="text-sm text-secondary mt-1">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── CTA ─── */}
      <section className="py-20 px-4">
        <div className="max-w-3xl mx-auto" data-reveal>
          <div className="relative card-gradient p-10 sm:p-14 text-center overflow-hidden">
            {/* Glow */}
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-64 rounded-full bg-orange-500/15 blur-3xl animate-pulse-glow" />
            </div>
            <div className="relative z-10">
              <div className="inline-flex p-4 rounded-2xl bg-gradient-to-br from-orange-500 to-orange-700 text-white shadow-xl shadow-orange-500/20 mb-6">
                <TrendingUp size={32} />
              </div>
              <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">
                Ready to trade with <span className="text-gradient">intention?</span>
              </h2>
              <p className="mt-4 text-secondary max-w-md mx-auto">
                Start your journal today. Invite your accountability partner. Trade better tomorrow.
              </p>
              <button onClick={onEnter} className="btn-primary text-base px-8 py-3 mt-8">
                {session ? 'Open Your Dashboard' : 'Create Your Free Account'}
                <ArrowRight size={18} />
              </button>
              <div className="mt-6 flex items-center justify-center gap-4 text-xs text-muted">
                <span className="flex items-center gap-1"><CheckCircle2 size={14} className="text-success-500" /> No credit card</span>
                <span className="flex items-center gap-1"><CheckCircle2 size={14} className="text-success-500" /> Free forever</span>
                <span className="flex items-center gap-1"><CheckCircle2 size={14} className="text-success-500" /> Private by default</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─── FOOTER ─── */}
      <footer className="py-10 px-4 border-t border-themed">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-gradient-to-br from-orange-500 to-orange-700 text-white">
              <TrendingUp size={18} />
            </div>
            <span className="font-bold text-sm">TradeJournal Pro</span>
          </div>
          <p className="text-xs text-muted">Built for accountability. Designed for growth.</p>
          <div className="flex items-center gap-3 text-muted">
            <Star size={14} className="text-orange-500" />
            <Star size={14} className="text-orange-500" />
            <Star size={14} className="text-orange-500" />
            <Star size={14} className="text-orange-500" />
            <Star size={14} className="text-orange-500" />
          </div>
        </div>
      </footer>
    </div>
  );
}
