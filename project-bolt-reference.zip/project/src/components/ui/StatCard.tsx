import { useState, type ReactNode, type MouseEvent } from 'react';
import { AnimatedCounter } from '@/components/ui/AnimatedCounter';

interface StatCardProps {
  label: string;
  value: string;
  sublabel?: string;
  icon?: ReactNode;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  accent?: 'blue' | 'emerald' | 'amber' | 'rose';
}

const ACCENT_GLOW: Record<NonNullable<StatCardProps['accent']>, string> = {
  blue: 'glow-accent-blue',
  emerald: 'glow-accent-emerald',
  amber: 'glow-accent-amber',
  rose: 'glow-accent-rose',
};

const ACCENT_STROKE: Record<NonNullable<StatCardProps['accent']>, string> = {
  blue: '#f97316',
  emerald: '#10b981',
  amber: '#eab308',
  rose: '#f54030',
};

const SPARKLINE_PATH = 'M0,26 Q15,18 30,21 T60,14 T90,17 T120,8';

export function StatCard({ label, value, sublabel, icon, trend, trendValue, accent = 'blue' }: StatCardProps) {
  const [tilt, setTilt] = useState({ rx: 0, ry: 0 });
  const numericValue = parseFloat(value);
  const isNumeric = !isNaN(numericValue) && isFinite(numericValue);

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({ rx: -y * 10, ry: x * 10 });
  };

  const handleMouseLeave = () => setTilt({ rx: 0, ry: 0 });

  return (
    <div
      className="card card-interactive p-5 animate-slide-up group relative overflow-hidden"
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{ transform: `perspective(600px) rotateX(${tilt.rx}deg) rotateY(${tilt.ry}deg)` }}
    >
      <div className="absolute inset-x-0 top-0 h-0.5 bg-gradient-to-r from-orange-400 via-amber-400 to-orange-500 animate-top-line" />
      <div className={`absolute -top-16 -right-16 w-40 h-40 rounded-full blur-3xl opacity-60 ${ACCENT_GLOW[accent]}`} />
      <div className="absolute -top-12 -right-12 w-32 h-32 rounded-full bg-orange-500/0 group-hover:bg-orange-500/5 blur-2xl transition-all duration-500" />

      <div className="flex items-start justify-between relative">
        <div className="min-w-0">
          <p className="text-xs font-semibold text-muted uppercase tracking-wider">{label}</p>
          <p className="mt-2 text-2xl font-bold font-mono tracking-tight">
            {isNumeric ? <AnimatedCounter value={numericValue} /> : value}
          </p>
          {sublabel && <p className="mt-1 text-xs text-muted truncate">{sublabel}</p>}
        </div>
        {icon && (
          <div className="relative">
            <div className={`absolute inset-0 rounded-xl blur-md animate-pulse-glow ${ACCENT_GLOW[accent]}`} />
            <div className={`relative p-2.5 rounded-xl border border-themed transition-transform group-hover:scale-110 duration-200 icon-bg-${accent}`}>
              {icon}
            </div>
          </div>
        )}
      </div>
      {trend && trendValue && (
        <div className="mt-3 flex items-center gap-1.5 relative">
          <span className={`text-xs font-semibold ${trend === 'up' ? 'text-success-500' : trend === 'down' ? 'text-error-500' : 'text-muted'}`}>
            {trend === 'up' ? '↑' : trend === 'down' ? '↓' : '—'} {trendValue}
          </span>
        </div>
      )}
      <svg className="absolute bottom-0 left-0 w-full h-10 opacity-25" viewBox="0 0 120 32" preserveAspectRatio="none">
        <path d={SPARKLINE_PATH} fill="none" stroke={ACCENT_STROKE[accent]} strokeWidth="1.5" className="animate-sparkline" />
      </svg>
    </div>
  );
}
