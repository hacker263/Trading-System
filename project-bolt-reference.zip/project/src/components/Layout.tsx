import { useState, useLayoutEffect, useRef, type ReactNode, type MouseEvent } from 'react';
import { LayoutDashboard, CandlestickChart, Calendar, BarChart3, BookOpen, Sparkles, Moon, Sun, Menu, X, TrendingUp, Plus, Trophy, Swords, LogOut, ChevronDown } from 'lucide-react';
import { useTheme } from '@/context/ThemeContext';
import { useAuth } from '@/context/AuthContext';

export type PageId = 'dashboard' | 'trades' | 'calendar' | 'analytics' | 'journal' | 'ai' | 'leaderboard' | 'compare';

interface LayoutProps {
  current: PageId;
  onNavigate: (page: PageId) => void;
  onQuickAdd: () => void;
  children: ReactNode;
}

const NAV_SECTIONS: { label: string; items: { id: PageId; label: string; icon: typeof LayoutDashboard }[] }[] = [
  {
    label: 'Personal',
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { id: 'trades', label: 'Trades', icon: CandlestickChart },
      { id: 'calendar', label: 'Calendar', icon: Calendar },
      { id: 'analytics', label: 'Analytics', icon: BarChart3 },
      { id: 'journal', label: 'Journal', icon: BookOpen },
      { id: 'ai', label: 'AI Insights', icon: Sparkles },
    ],
  },
  {
    label: 'Together',
    items: [
      { id: 'leaderboard', label: 'Overview', icon: Trophy },
      { id: 'compare', label: 'Side-by-Side', icon: Swords },
    ],
  },
];

interface RippleState {
  id: number;
  x: number;
  y: number;
}

export function Layout({ current, onNavigate, onQuickAdd, children }: LayoutProps) {
  const { theme, toggle } = useTheme();
  const { profile, signOut } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const [indicator, setIndicator] = useState({ top: 0, height: 0, ready: false });
  const [ripples, setRipples] = useState<RippleState[]>([]);
  const navRef = useRef<HTMLElement>(null);

  useLayoutEffect(() => {
    const nav = navRef.current;
    if (!nav) return;
    const activeBtn = nav.querySelector('[data-active="true"]') as HTMLElement | null;
    if (activeBtn) {
      setIndicator({ top: activeBtn.offsetTop, height: activeBtn.offsetHeight, ready: true });
    }
  }, [current]);

  const handleNav = (page: PageId) => {
    onNavigate(page);
    setMobileOpen(false);
  };

  const handleQuickAddClick = (e: MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const id = Date.now();
    setRipples(prev => [...prev, { id, x: e.clientX - rect.left, y: e.clientY - rect.top }]);
    setTimeout(() => setRipples(prev => prev.filter(r => r.id !== id)), 600);
    onQuickAdd();
  };

  const displayName = profile?.display_name || 'Trader';
  const initials = displayName.charAt(0).toUpperCase();

  return (
    <div className="min-h-screen bg-primary flex">
      <aside
        className={`fixed lg:sticky top-0 left-0 h-screen w-64 bg-card border-r border-themed z-40 flex flex-col transition-transform duration-300 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="absolute top-0 left-0 right-0 h-20 pointer-events-none overflow-hidden">
          <div className="absolute top-0 left-1/3 w-24 h-16 bg-orange-500/12 blur-3xl rounded-full"
            style={{ animation: 'nav-glow-drift 7s ease-in-out infinite' }} />
        </div>

        <div className="relative flex items-center gap-3 px-6 py-5 border-b border-themed">
          <div className="relative p-2 rounded-xl bg-gradient-to-br from-orange-500 to-orange-700 text-white shadow-md shadow-orange-500/20">
            <TrendingUp size={22} />
            <span className="absolute -top-0.5 -right-0.5">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-60 animate-ping" />
                <span className="relative inline-flex w-2 h-2 rounded-full bg-amber-400 ring-2 ring-card" />
              </span>
            </span>
          </div>
          <div>
            <h1 className="font-bold text-sm tracking-tight">TradeJournal Pro</h1>
            <p className="text-[11px] text-muted">Accountability Journal</p>
          </div>
          <button onClick={() => setMobileOpen(false)} className="ml-auto lg:hidden btn-ghost p-1">
            <X size={18} />
          </button>
        </div>

        <nav ref={navRef} className="relative flex-1 px-3 py-4 overflow-y-auto">
          <div className="space-y-4">
            {NAV_SECTIONS.map(section => (
              <div key={section.label}>
                <p className="px-3 mb-1.5 text-[10px] font-bold uppercase tracking-wider text-muted">{section.label}</p>
                <div className="space-y-0.5">
                  {section.items.map(item => {
                    const Icon = item.icon;
                    const active = current === item.id;
                    return (
                      <button
                        key={item.id}
                        data-active={active}
                        onClick={() => handleNav(item.id)}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 relative group ${
                          active
                            ? 'bg-orange-500/10 text-orange-600 dark:text-orange-400'
                            : 'text-secondary hover:bg-secondary hover:text-primary'
                        }`}
                      >
                        <Icon size={18} className={`transition-transform duration-200 group-hover:scale-110 group-hover:translate-x-0.5 ${active ? 'text-orange-500' : ''}`} />
                        {item.label}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
          {indicator.ready && (
            <div
              className="absolute left-3 w-1 rounded-r-full bg-gradient-to-b from-orange-400 to-orange-600 transition-all duration-300 ease-out"
              style={{ top: indicator.top, height: indicator.height }}
            />
          )}
          <div className="sticky bottom-0 left-0 right-0 h-8 -mx-3 -mb-4 pointer-events-none bg-gradient-to-t from-card via-card/90 to-transparent" />
        </nav>

        <div className="px-3 py-3 border-t border-themed">
          <div className="relative">
            <button
              onClick={() => setProfileMenuOpen(o => !o)}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-secondary hover:bg-secondary hover:text-primary transition-all"
            >
              {profile?.avatar_url ? (
                <img src={profile.avatar_url} alt={displayName} className="w-8 h-8 rounded-full object-cover ring-2 ring-orange-500/20" />
              ) : (
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-500 to-orange-700 flex items-center justify-center text-white text-xs font-bold shadow-sm">
                  {initials}
                </div>
              )}
              <span className="truncate flex-1 text-left">{displayName}</span>
              <ChevronDown size={16} className={`transition-transform duration-200 ${profileMenuOpen ? 'rotate-180' : ''}`} />
            </button>
            {profileMenuOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setProfileMenuOpen(false)} />
                <div className="absolute bottom-full left-0 right-0 mb-2 card border border-themed rounded-xl overflow-hidden shadow-xl z-50 animate-scale-in">
                  <button onClick={toggle} className="w-full flex items-center gap-3 px-4 py-3 text-sm hover:bg-secondary transition-colors">
                    {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
                    {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
                  </button>
                  <div className="border-t border-themed" />
                  <button onClick={() => { signOut(); }} className="w-full flex items-center gap-3 px-4 py-3 text-sm text-error-500 hover:bg-error-500/10 transition-colors">
                    <LogOut size={16} /> Sign Out
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </aside>

      {mobileOpen && <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-30 lg:hidden" onClick={() => setMobileOpen(false)} />}

      <div className="flex-1 min-w-0">
        <div className="lg:hidden sticky top-0 z-20 flex items-center justify-between px-4 py-3 bg-card/80 backdrop-blur-md border-b border-themed">
          <button onClick={() => setMobileOpen(true)} className="btn-ghost p-1.5">
            <Menu size={20} />
          </button>
          <div className="flex items-center gap-2">
            <TrendingUp size={18} className="text-orange-500" />
            <span className="font-bold text-sm">TradeJournal Pro</span>
          </div>
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-500 to-orange-700 flex items-center justify-center text-white text-xs font-bold">
            {initials}
          </div>
        </div>

        <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto animate-fade-in pb-24 lg:pb-8">{children}</main>

        <button
          onClick={handleQuickAddClick}
          className="fixed bottom-6 right-6 z-30 w-14 h-14 rounded-full bg-gradient-to-br from-orange-500 to-orange-700 text-white shadow-lg shadow-orange-500/30 flex items-center justify-center transition-all duration-300 hover:scale-110 active:scale-95 group relative overflow-hidden"
          title="Quick Add Trade"
        >
          <div className="absolute -inset-1 rounded-full bg-orange-500/25 blur-md opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-pulse-glow" />
          <div className="absolute inset-0 rounded-full ring-2 ring-orange-300/0 group-hover:ring-orange-300/50 transition-all duration-300" />
          {ripples.map(r => (
            <span key={r.id} className="ripple" style={{ left: r.x - 6, top: r.y - 6, width: 12, height: 12 }} />
          ))}
          <Plus size={26} className="relative group-hover:rotate-90 transition-transform duration-300" />
        </button>
      </div>
    </div>
  );
}
