import { useState, useEffect, useMemo } from 'react';
import { Save, X, Calculator, TrendingUp, TrendingDown, Zap, ChevronRight, ChevronLeft, CheckCircle2, Image, Mic, PenLine, Target, Brain, AlertTriangle, Clock, CheckCircle, ListChecks, Camera, MessageSquare, Lock } from 'lucide-react';
import type { Trade, TradeInput, TradeDirection, TradeSession, AccountType, EmotionalState, TradeStatus, TradeChecklistSnapshot } from '@/lib/types';
import { calcPips, calcPnl, formatCurrency, formatPips, getInstrumentType } from '@/lib/utils';
import { PAIR_SUGGESTIONS, BROKER_SUGGESTIONS, LESSON_SUGGESTIONS, NOTE_SUGGESTIONS } from '@/lib/suggestions';
import { useStrategies, useStrategyChecklist } from '@/hooks/useData';
import { useAuth } from '@/context/AuthContext';
import { VoiceRecorder } from './VoiceRecorder';
import { ScreenshotUpload } from './ScreenshotUpload';
import { SuggestInput } from './ui/SuggestInput';
import { PreTradeChecklist } from './PreTradeChecklist';

interface TradeFormProps {
  initial?: Trade | null;
  onSubmit: (data: TradeInput) => Promise<void>;
  onCancel: () => void;
}

const MISTAKE_OPTIONS = [
  'Overtraded', 'Broke my rules', 'Chased the market', 'Moved my stop loss', 'No clear setup',
  'Revenge trade', 'FOMO entry', 'Ignored higher timeframe', 'Sized too large', 'Exited too early',
  'Held too long', 'Traded against trend', 'No stop loss', 'Traded the news',
];

const STEPS = [
  { id: 0, label: 'Strategy', icon: Target },
  { id: 1, label: 'Trade', icon: TrendingUp },
  { id: 2, label: 'Context', icon: Brain },
  { id: 3, label: 'Entry Media', icon: Camera },
  { id: 4, label: 'Closure', icon: CheckCircle },
];

export function TradeForm({ initial, onSubmit, onCancel }: TradeFormProps) {
  const { user } = useAuth();
  const { strategies } = useStrategies(user?.id);

  const [form, setForm] = useState<TradeInput>(() => initial ? { ...initial } : {
    pair: '', direction: 'long', entry_price: null, exit_price: null, take_profit: null,
    lot_size: null, outcome: null, status: 'open', pnl: 0, pips: 0,
    strategy: '', strategy_id: null, session: null, broker: '', account_type: null,
    entry_time: new Date().toISOString().slice(0, 16), exit_time: null,
    risk_percent: null, risk_reward_ratio: null, emotional_state: null,
    setup_quality: null, mistakes: [], lessons: '', notes: '',
    screenshot_url: null, voice_note_url: null,
    entry_screenshot_url: null, entry_voice_note_url: null,
    closure_screenshot_url: null, closure_voice_note_url: null,
    what_went_wrong: null, observations: null,
    checklist_items: null, checklist_override_reason: null, checklist_completed: false,
  });
  const [stopLoss, setStopLoss] = useState<string>(initial?.entry_price ? '' : '');
  const [checklistSnapshot, setChecklistSnapshot] = useState<TradeChecklistSnapshot[]>([]);
  const [checklistOverrideReason, setChecklistOverrideReason] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState(0);

  const { items: strategyChecklistItems } = useStrategyChecklist(form.strategy_id);

  useEffect(() => {
    if (initial) {
      setForm({ ...initial });
      setChecklistSnapshot(initial.checklist_items ?? []);
      setChecklistOverrideReason(initial.checklist_override_reason ?? null);
    }
  }, [initial]);

  const update = (field: keyof TradeInput, value: any) => {
    setForm(f => ({ ...f, [field]: value }));
  };

  const toggleMistake = (mistake: string) => {
    setForm(f => ({
      ...f,
      mistakes: f.mistakes.includes(mistake)
        ? f.mistakes.filter(m => m !== mistake)
        : [...f.mistakes, mistake],
    }));
  };

  const liveCalc = useMemo(() => {
    const entry = form.entry_price;
    const exit = form.exit_price;
    const tp = form.take_profit;
    const sl = stopLoss ? parseFloat(stopLoss) : null;
    const lot = form.lot_size;
    const pair = form.pair;
    const direction = form.direction;

    let pips = 0;
    let pnl = 0;
    let rr: number | null = null;
    let outcome: 'win' | 'loss' | 'breakeven' | null = null;
    let potentialPips = 0;
    let potentialPnl = 0;
    let potentialRr: number | null = null;

    if (entry != null && exit != null && pair) {
      pips = calcPips(pair, direction, entry, exit);
      if (lot) pnl = calcPnl(pips, lot, pair);
      outcome = pnl > 0 ? 'win' : pnl < 0 ? 'loss' : 'breakeven';
    }

    if (entry != null && sl != null) {
      const risk = Math.abs(entry - sl);
      const reward = exit != null
        ? (direction === 'long' ? exit - entry : entry - exit)
        : tp != null
          ? (direction === 'long' ? tp - entry : entry - tp)
          : null;
      if (risk > 0 && reward != null) rr = reward / risk;
    }

    if (entry != null && tp != null && pair && lot) {
      potentialPips = calcPips(pair, direction, entry, tp);
      potentialPnl = calcPnl(potentialPips, lot, pair);
      const risk = sl != null ? Math.abs(entry - sl) : null;
      if (risk && risk > 0) {
        const reward = direction === 'long' ? tp - entry : entry - tp;
        potentialRr = reward / risk;
      }
    }

    const hasData = entry != null && pair.length > 0;
    const isClosed = exit != null;
    const instType = pair ? getInstrumentType(pair) : 'fx';

    return { pips, pnl, rr, outcome, potentialPips, potentialPnl, potentialRr, hasData, isClosed, instType };
  }, [form.entry_price, form.exit_price, form.take_profit, form.lot_size, form.pair, form.direction, stopLoss]);

  const handleSubmit = async () => {
    setSaving(true);
    setError(null);
    if (!form.pair.trim()) {
      setError('Please enter a currency pair (e.g. EUR/USD).');
      setSaving(false);
      return;
    }
    if (form.entry_price == null) {
      setError('Please enter an entry price.');
      setSaving(false);
      return;
    }
    if (!form.lot_size) {
      setError('Please enter a lot size.');
      setSaving(false);
      return;
    }

    const autoStatus: TradeStatus = form.exit_price != null ? 'closed' : 'open';
    const autoPips = liveCalc.pips;
    const autoPnl = liveCalc.pnl;
    const autoOutcome = liveCalc.outcome;
    const autoRr = liveCalc.rr;

    const allRequiredChecked = strategyChecklistItems.length > 0 && strategyChecklistItems.filter(i => i.is_required).every(item =>
      checklistSnapshot.some(s => s.label === item.label && s.checked)
    );

    const finalData: TradeInput = {
      ...form,
      status: autoStatus,
      pips: parseFloat(autoPips.toFixed(1)),
      pnl: parseFloat(autoPnl.toFixed(2)),
      outcome: autoStatus === 'open' ? null : autoOutcome,
      risk_reward_ratio: autoRr != null ? parseFloat(autoRr.toFixed(2)) : form.risk_reward_ratio,
      entry_time: new Date(form.entry_time).toISOString(),
      exit_time: form.exit_time ? new Date(form.exit_time).toISOString() : null,
      screenshot_url: form.entry_screenshot_url,
      voice_note_url: form.entry_voice_note_url,
      checklist_items: checklistSnapshot.length > 0 ? checklistSnapshot : null,
      checklist_override_reason: checklistOverrideReason,
      checklist_completed: allRequiredChecked,
    };

    try {
      await onSubmit(finalData);
    } catch (err: any) {
      setError(err.message || 'Failed to save trade.');
      setSaving(false);
    }
  };

  const inputCls = 'input-field';
  const labelCls = 'block text-xs font-semibold text-secondary mb-1.5 uppercase tracking-wide';

  const isEditMode = !!initial;
  const isClosedTrade = form.exit_price != null;

  const canAdvance = (s: number) => {
    if (s === 0) return form.strategy_id != null;
    if (s === 1) return form.pair.trim().length > 0 && form.entry_price != null && form.lot_size != null;
    if (s === 4) return isClosedTrade;
    return true;
  };

  const closureStepUnlocked = isClosedTrade;
  const lastStep = STEPS.length - 1;

  return (
    <div className="space-y-5">
      {error && (
        <div className="flex items-center gap-2 p-3 rounded-lg bg-error-500/10 border border-error-500/20 text-sm text-error-500 animate-slide-up">
          <AlertTriangle size={16} className="flex-shrink-0" />
          {error}
        </div>
      )}

      <div className="flex items-center gap-2 p-3 rounded-xl bg-secondary border border-themed">
        {isClosedTrade ? (
          <>
            <CheckCircle size={16} className="text-success-500" />
            <span className="text-xs font-semibold text-secondary">Closed Trade — exit price is set, outcome auto-calculated. Closure review available.</span>
          </>
        ) : (
          <>
            <Clock size={16} className="text-orange-500" />
            <span className="text-xs font-semibold text-secondary">Open Trade — no exit price yet. Fill in closure details when you close it.</span>
          </>
        )}
      </div>

      <div className="flex items-center gap-1 sm:gap-2">
        {STEPS.map((s, i) => {
          const Icon = s.icon;
          const done = i < step;
          const active = i === step;
          const locked = s.id === 4 && !closureStepUnlocked;
          return (
            <div key={s.id} className="flex items-center flex-1">
              <button
                type="button"
                onClick={() => !locked && canAdvance(i) && setStep(i)}
                className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  locked ? 'text-muted/50 cursor-not-allowed' :
                  active ? 'bg-orange-500/10 text-orange-600 dark:text-orange-400' :
                  done ? 'text-success-500' : 'text-muted'
                }`}
              >
                {locked ? <Lock size={16} /> : done ? <CheckCircle2 size={16} /> : <Icon size={16} />}
                <span className="hidden sm:inline">{s.label}</span>
              </button>
              {i < lastStep && (
                <div className={`flex-1 h-0.5 mx-1 rounded-full transition-colors ${done ? 'bg-success-500/30' : 'bg-border'}`} />
              )}
            </div>
          );
        })}
      </div>

      {liveCalc.hasData && step === 1 && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-gradient-to-br from-orange-500/5 to-amber-500/10 border border-orange-500/20 animate-slide-up">
          {liveCalc.isClosed ? (
            <>
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-orange-500/10">
                  <Calculator size={16} className="text-orange-500" />
                </div>
                <div>
                  <p className="text-[10px] font-semibold text-muted uppercase">Pips</p>
                  <p className="text-sm font-mono font-bold">{formatPips(liveCalc.pips)}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className={`p-2 rounded-lg ${liveCalc.pnl >= 0 ? 'bg-success-500/10' : 'bg-error-500/10'}`}>
                  {liveCalc.pnl >= 0 ? <TrendingUp size={16} className="text-success-500" /> : <TrendingDown size={16} className="text-error-500" />}
                </div>
                <div>
                  <p className="text-[10px] font-semibold text-muted uppercase">P&L (auto)</p>
                  <p className={`text-sm font-mono font-bold ${liveCalc.pnl >= 0 ? 'text-success-500' : 'text-error-500'}`}>
                    {formatCurrency(liveCalc.pnl)}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-amber-500/10">
                  <Zap size={16} className="text-amber-500" />
                </div>
                <div>
                  <p className="text-[10px] font-semibold text-muted uppercase">R:R</p>
                  <p className="text-sm font-mono font-bold">
                    {liveCalc.rr != null ? `1:${liveCalc.rr.toFixed(2)}` : '—'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className={`p-2 rounded-lg ${liveCalc.outcome === 'win' ? 'bg-success-500/10' : liveCalc.outcome === 'loss' ? 'bg-error-500/10' : 'bg-secondary'}`}>
                  <span className={`text-xs font-bold ${liveCalc.outcome === 'win' ? 'text-success-500' : liveCalc.outcome === 'loss' ? 'text-error-500' : 'text-muted'}`}>
                    {liveCalc.outcome ? liveCalc.outcome.toUpperCase() : '—'}
                  </span>
                </div>
                <div>
                  <p className="text-[10px] font-semibold text-muted uppercase">Outcome (auto)</p>
                  <p className="text-sm font-semibold capitalize">{liveCalc.outcome || '—'}</p>
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-orange-500/10">
                  <Clock size={16} className="text-orange-500" />
                </div>
                <div>
                  <p className="text-[10px] font-semibold text-muted uppercase">Status</p>
                  <p className="text-sm font-bold text-orange-500">OPEN</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-amber-500/10">
                  <Zap size={16} className="text-amber-500" />
                </div>
                <div>
                  <p className="text-[10px] font-semibold text-muted uppercase">Potential Pips</p>
                  <p className="text-sm font-mono font-bold">{form.take_profit ? formatPips(liveCalc.potentialPips) : '—'}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-success-500/10">
                  <TrendingUp size={16} className="text-success-500" />
                </div>
                <div>
                  <p className="text-[10px] font-semibold text-muted uppercase">Potential P&L</p>
                  <p className="text-sm font-mono font-bold text-success-500">
                    {form.take_profit && form.lot_size ? formatCurrency(liveCalc.potentialPnl) : '—'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-amber-500/10">
                  <Zap size={16} className="text-amber-500" />
                </div>
                <div>
                  <p className="text-[10px] font-semibold text-muted uppercase">Potential R:R</p>
                  <p className="text-sm font-mono font-bold">
                    {liveCalc.potentialRr != null ? `1:${liveCalc.potentialRr.toFixed(2)}` : '—'}
                  </p>
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {step === 0 && (
        <div className="space-y-4 animate-fade-in">
          <div>
            <label className={labelCls}>Strategy *</label>
            {strategies.length > 0 ? (
              <select
                className={inputCls}
                value={form.strategy_id || ''}
                onChange={e => {
                  const id = e.target.value || null;
                  const strat = strategies.find(s => s.id === id);
                  update('strategy_id', id);
                  update('strategy', strat?.name || '');
                }}
              >
                <option value="">Select strategy</option>
                {strategies.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            ) : (
              <p className="text-xs text-muted py-2">No strategies set up. Add strategies in onboarding or settings.</p>
            )}
          </div>

          {form.strategy_id && strategyChecklistItems.length > 0 && (
            <PreTradeChecklist
              items={strategyChecklistItems}
              snapshot={checklistSnapshot}
              overrideReason={checklistOverrideReason}
              onSnapshotChange={setChecklistSnapshot}
              onOverrideReasonChange={setChecklistOverrideReason}
            />
          )}

          {form.strategy_id && strategyChecklistItems.length === 0 && (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <ListChecks size={36} className="text-muted mb-3" />
              <p className="text-sm font-semibold">No checklist for this strategy</p>
              <p className="text-xs text-muted mt-1">You can add checklist items to this strategy in the strategies settings.</p>
            </div>
          )}

          {!form.strategy_id && (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <Target size={36} className="text-muted mb-3" />
              <p className="text-sm font-semibold">Select a strategy to begin</p>
              <p className="text-xs text-muted mt-1">Each strategy has its own checklist that guides your entry.</p>
            </div>
          )}
        </div>
      )}

      {step === 1 && (
        <div className="space-y-4 animate-fade-in">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className={labelCls}>Currency Pair *</label>
              <SuggestInput value={form.pair} onChange={v => update('pair', v)} placeholder="EUR/USD" suggestions={PAIR_SUGGESTIONS} />
            </div>
            <div>
              <label className={labelCls}>Direction *</label>
              <select className={inputCls} value={form.direction}
                onChange={e => update('direction', e.target.value as TradeDirection)}>
                <option value="long">Long (Buy)</option>
                <option value="short">Short (Sell)</option>
              </select>
            </div>
            <div>
              <label className={labelCls}>Lot Size *</label>
              <input type="number" step="0.01" className={inputCls} placeholder="0.50"
                value={form.lot_size ?? ''} onChange={e => update('lot_size', e.target.value ? parseFloat(e.target.value) : null)} />
            </div>
            <div>
              <label className={labelCls}>Entry Price *</label>
              <input type="number" step="0.00001" className={inputCls} placeholder="1.08500"
                value={form.entry_price ?? ''} onChange={e => update('entry_price', e.target.value ? parseFloat(e.target.value) : null)} />
            </div>
            <div>
              <label className={labelCls}>Stop Loss</label>
              <input type="number" step="0.00001" className={inputCls} placeholder="1.08300"
                value={stopLoss} onChange={e => setStopLoss(e.target.value)} />
            </div>
            <div>
              <label className={labelCls}>Take Profit</label>
              <input type="number" step="0.00001" className={inputCls} placeholder="1.09000"
                value={form.take_profit ?? ''} onChange={e => update('take_profit', e.target.value ? parseFloat(e.target.value) : null)} />
            </div>
            <div>
              <label className={labelCls}>Exit Price {isEditMode ? '' : '(leave empty for open trade)'}</label>
              <input type="number" step="0.00001" className={inputCls} placeholder="1.08700"
                value={form.exit_price ?? ''} onChange={e => update('exit_price', e.target.value ? parseFloat(e.target.value) : null)} />
            </div>
            <div>
              <label className={labelCls}>Entry Date & Time *</label>
              <input type="datetime-local" className={inputCls}
                value={form.entry_time ? form.entry_time.slice(0, 16) : ''} onChange={e => update('entry_time', e.target.value)} />
            </div>
            <div>
              <label className={labelCls}>Exit Date & Time</label>
              <input type="datetime-local" className={inputCls}
                value={form.exit_time ? form.exit_time.slice(0, 16) : ''} onChange={e => update('exit_time', e.target.value || null)} />
            </div>
          </div>
          <p className="text-xs text-muted">
            Pips, P&L, outcome, and risk-to-reward are calculated automatically from your entry, exit, stop loss, and lot size.
            Leave exit price empty to record an open trade — come back and fill it when you close the position.
          </p>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-4 animate-fade-in">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className={labelCls}>Session</label>
              <select className={inputCls} value={form.session || ''}
                onChange={e => update('session', (e.target.value || null) as TradeSession)}>
                <option value="">—</option>
                <option value="sydney">Sydney</option>
                <option value="asian">Asian</option>
                <option value="london">London</option>
                <option value="new_york">New York</option>
                <option value="overlap">London/NY Overlap</option>
              </select>
            </div>
            <div>
              <label className={labelCls}>Broker / Prop Firm</label>
              <SuggestInput value={form.broker || ''} onChange={v => update('broker', v)} placeholder="FTMO, IC Markets..." suggestions={BROKER_SUGGESTIONS} />
            </div>
            <div>
              <label className={labelCls}>Account Type</label>
              <select className={inputCls} value={form.account_type || ''}
                onChange={e => update('account_type', (e.target.value || null) as AccountType)}>
                <option value="">—</option>
                <option value="personal">Personal Funds</option>
                <option value="propfirm">Prop Firm</option>
              </select>
            </div>
            <div>
              <label className={labelCls}>Risk %</label>
              <input type="number" step="0.1" className={inputCls} placeholder="1.0"
                value={form.risk_percent ?? ''} onChange={e => update('risk_percent', e.target.value ? parseFloat(e.target.value) : null)} />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className={labelCls}>Emotional State</label>
              <select className={inputCls} value={form.emotional_state || ''}
                onChange={e => update('emotional_state', (e.target.value || null) as EmotionalState)}>
                <option value="">—</option>
                <option value="calm">Calm</option>
                <option value="confident">Confident</option>
                <option value="focused">Focused</option>
                <option value="rushed">Rushed</option>
                <option value="frustrated">Frustrated</option>
                <option value="anxious">Anxious</option>
                <option value="greedy">Greedy</option>
                <option value="fearful">Fearful</option>
              </select>
            </div>
            <div>
              <label className={labelCls}>Setup Quality</label>
              <div className="flex items-center gap-1 h-[42px]">
                {[1, 2, 3, 4, 5].map(star => (
                  <button key={star} type="button" onClick={() => update('setup_quality', star)}>
                    <Zap size={24}
                      className={`transition-transform hover:scale-125 ${star <= (form.setup_quality || 0) ? 'fill-amber-400 text-amber-400' : 'text-muted'}`}
                    />
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-4 animate-fade-in">
          <p className="text-sm text-secondary">
            Record your thought process as you enter this trade. This is your entry setup — upload a screenshot and/or record a voice note.
          </p>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div>
              <label className={labelCls}>Setup Screenshot</label>
              <ScreenshotUpload onUpload={url => update('entry_screenshot_url', url)} existingUrl={form.entry_screenshot_url} />
            </div>
            <div>
              <label className={labelCls}>Entry Voice Note</label>
              <VoiceRecorder onUpload={url => update('entry_voice_note_url', url)} existingUrl={form.entry_voice_note_url} />
            </div>
          </div>
        </div>
      )}

      {step === 4 && (
        <div className="space-y-4 animate-fade-in">
          {!isClosedTrade ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="p-4 rounded-2xl bg-orange-500/10 mb-4">
                <Clock size={36} className="text-orange-500" />
              </div>
              <p className="text-sm font-semibold mb-1">This trade is still open</p>
              <p className="text-xs text-muted max-w-sm">
                You can add your closure review — what went wrong, observations, lessons, and closure screenshots —
                once you close the trade by entering an exit price in the Trade step.
              </p>
            </div>
          ) : (
            <>
              <div className="p-3 rounded-xl bg-success-500/5 border border-success-500/15">
                <p className="text-xs font-semibold text-success-500 flex items-center gap-2">
                  <CheckCircle size={14} /> Trade is closed — fill in your review below
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className={labelCls}>Exit Date & Time</label>
                  <input type="datetime-local" className={inputCls}
                    value={form.exit_time ? form.exit_time.slice(0, 16) : ''} onChange={e => update('exit_time', e.target.value || null)} />
                </div>
              </div>

              <div>
                <label className={labelCls}>What Went Wrong</label>
                <textarea
                  className={inputCls}
                  rows={2}
                  placeholder="If this was a loss, what was the mistake? If a win, what could have been better?"
                  value={form.what_went_wrong || ''}
                  onChange={e => update('what_went_wrong', e.target.value || null)}
                />
              </div>

              <div>
                <label className={labelCls}>Observations</label>
                <textarea
                  className={inputCls}
                  rows={2}
                  placeholder="What did you notice about the market, your execution, or your psychology?"
                  value={form.observations || ''}
                  onChange={e => update('observations', e.target.value || null)}
                />
              </div>

              <div>
                <label className={labelCls}>What I Learned</label>
                <SuggestInput multiline rows={2} value={form.lessons || ''} onChange={v => update('lessons', v)} placeholder="Key takeaway from this trade..." suggestions={LESSON_SUGGESTIONS} />
              </div>

              <div>
                <label className={labelCls}>Mistake Checklist</label>
                <p className="text-xs text-muted mb-2.5 -mt-1">Be honest. This is between you and your accountability partner.</p>
                <div className="flex flex-wrap gap-2">
                  {MISTAKE_OPTIONS.map(m => (
                    <button key={m} type="button" onClick={() => toggleMistake(m)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                        form.mistakes.includes(m)
                          ? 'bg-error-500/15 border-error-500/30 text-error-500'
                          : 'bg-secondary border-themed text-secondary hover:border-muted'
                      }`}>
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div>
                  <label className={labelCls}>Closure Screenshot</label>
                  <ScreenshotUpload onUpload={url => update('closure_screenshot_url', url)} existingUrl={form.closure_screenshot_url} />
                </div>
                <div>
                  <label className={labelCls}>Closure Voice Note</label>
                  <VoiceRecorder onUpload={url => update('closure_voice_note_url', url)} existingUrl={form.closure_voice_note_url} />
                </div>
              </div>
            </>
          )}
        </div>
      )}

      <div className="flex items-center justify-between pt-3 border-t border-themed">
        <div className="flex items-center gap-2">
          {step > 0 && (
            <button type="button" onClick={() => setStep(s => s - 1)} className="btn-secondary">
              <ChevronLeft size={18} /> Back
            </button>
          )}
        </div>
        <div className="flex items-center gap-3">
          <button type="button" onClick={onCancel} className="btn-secondary">
            <X size={18} /> Cancel
          </button>
          {step < lastStep ? (
            <button type="button" onClick={() => canAdvance(step) && setStep(s => s + 1)} disabled={!canAdvance(step)} className="btn-primary">
              Next <ChevronRight size={18} />
            </button>
          ) : (
            <button type="button" onClick={handleSubmit} disabled={saving} className="btn-primary">
              <Save size={18} /> {saving ? 'Saving...' : isEditMode ? 'Update Trade' : 'Save Trade'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
