export interface RiskSettings {
  id: string;
  user_id: string;
  max_daily_loss_pct: number;
  max_daily_trades: number;
  max_risk_per_trade_pct: number;
  account_balance: number;
  max_drawdown_pct: number;
  daily_loss_limit_amount: number | null;
  created_at: string;
  updated_at: string;
}

export type RiskSettingsInput = Omit<RiskSettings, 'id' | 'user_id' | 'created_at' | 'updated_at'>;

export interface PreTradeChecklistItem {
  id: string;
  user_id: string;
  label: string;
  is_required: boolean;
  sort_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export type PreTradeChecklistInput = Omit<PreTradeChecklistItem, 'id' | 'user_id' | 'created_at' | 'updated_at'>;

export interface TradeChecklistSnapshot {
  label: string;
  checked: boolean;
}

export type TradeDirection = 'long' | 'short';
export type TradeOutcome = 'win' | 'loss' | 'breakeven' | null;
export type TradeStatus = 'open' | 'closed';
export type TradeSession = 'asian' | 'london' | 'new_york' | 'overlap' | 'sydney';
export type AccountType = 'personal' | 'propfirm';
export type EmotionalState = 'calm' | 'confident' | 'rushed' | 'frustrated' | 'focused' | 'anxious' | 'greedy' | 'fearful';

export interface StrategyChecklistItem {
  id: string;
  strategy_id: string;
  label: string;
  is_required: boolean;
  sort_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export type StrategyChecklistInput = Omit<StrategyChecklistItem, 'id' | 'strategy_id' | 'created_at' | 'updated_at'>;

export interface TraderStrategy {
  id: string;
  user_id: string;
  name: string;
  description: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export type TraderStrategyInput = Omit<TraderStrategy, 'id' | 'user_id' | 'created_at' | 'updated_at'>;

export interface Trade {
  id: string;
  user_id: string | null;
  pair: string;
  direction: TradeDirection;
  entry_price: number | null;
  exit_price: number | null;
  lot_size: number | null;
  take_profit: number | null;
  outcome: TradeOutcome;
  status: TradeStatus;
  pnl: number;
  pips: number;
  strategy: string | null;
  session: TradeSession | null;
  broker: string | null;
  account_type: AccountType | null;
  entry_time: string;
  exit_time: string | null;
  risk_percent: number | null;
  risk_reward_ratio: number | null;
  emotional_state: EmotionalState | null;
  setup_quality: number | null;
  mistakes: string[];
  lessons: string | null;
  notes: string | null;
  screenshot_url: string | null;
  voice_note_url: string | null;
  entry_screenshot_url: string | null;
  entry_voice_note_url: string | null;
  closure_screenshot_url: string | null;
  closure_voice_note_url: string | null;
  what_went_wrong: string | null;
  observations: string | null;
  strategy_id: string | null;
  checklist_items: TradeChecklistSnapshot[] | null;
  checklist_override_reason: string | null;
  checklist_completed: boolean;
  created_at: string;
  updated_at: string;
}

export type TradeInput = Omit<Trade, 'id' | 'user_id' | 'created_at' | 'updated_at'>;

export type JournalType = 'daily' | 'weekly' | 'monthly';

export interface ChecklistItem {
  label: string;
  checked: boolean;
}

export interface ReviewPrompt {
  question: string;
  answer: string;
}

export interface JournalEntry {
  id: string;
  user_id: string | null;
  entry_date: string;
  entry_type: JournalType;
  daily_goals: string | null;
  weekly_focus: string | null;
  pre_market_notes: string | null;
  post_session_review: string | null;
  trading_plan_checklist: ChecklistItem[];
  review_prompts: ReviewPrompt[];
  mood: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export type JournalInput = Omit<JournalEntry, 'id' | 'user_id' | 'created_at' | 'updated_at'>;

export interface AISummary {
  id: string;
  period_type: JournalType;
  period_start: string;
  period_end: string;
  summary: string;
  suggestions: string[];
  patterns: PatternInsight[];
  comparison: ComparisonData;
  trade_count: number;
  created_at: string;
}

export interface PatternInsight {
  title: string;
  detail: string;
  type: 'positive' | 'negative' | 'neutral';
}

export interface ComparisonData {
  current: Record<string, number | string>;
  previous: Record<string, number | string>;
  deltas: Record<string, number>;
}

export interface DashboardStats {
  totalPnl: number;
  totalTrades: number;
  winRate: number;
  wins: number;
  losses: number;
  breakevens: number;
  avgWin: number;
  avgLoss: number;
  bestDay: { date: string; pnl: number } | null;
  worstDay: { date: string; pnl: number } | null;
  maxConsecutiveWins: number;
  maxConsecutiveLosses: number;
  currentStreak: { type: 'win' | 'loss' | 'none'; count: number };
  profitFactor: number;
  expectancy: number;
  avgRiskReward: number;
}

export interface TraderProfile {
  id: string;
  display_name: string;
  avatar_url: string | null;
  bio: string | null;
  trading_style: string | null;
  is_public: boolean;
  created_at: string;
}
