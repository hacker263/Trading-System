export const PAIR_SUGGESTIONS = [
  // Major FX
  'EUR/USD', 'GBP/USD', 'USD/JPY', 'USD/CAD', 'USD/CHF', 'AUD/USD', 'NZD/USD',
  // Minor FX
  'EUR/GBP', 'EUR/JPY', 'GBP/JPY', 'EUR/AUD', 'GBP/AUD', 'EUR/CAD', 'AUD/JPY', 'CHF/JPY',
  'GBP/CAD', 'GBP/CHF', 'AUD/CAD', 'AUD/CHF', 'CAD/CHF', 'NZD/JPY', 'EUR/CHF', 'EUR/NZD',
  'GBP/NZD', 'AUD/NZD', 'CAD/JPY', 'NZD/CAD', 'NZD/CHF',
  // Exotic FX
  'USD/TRY', 'USD/ZAR', 'USD/MXN', 'USD/SGD', 'USD/HKD', 'USD/SEK', 'USD/NOK', 'USD/DKK',
  'EUR/TRY', 'EUR/SEK', 'EUR/NOK', 'EUR/PLN', 'EUR/HUF', 'EUR/CZK',
  // Metals
  'XAU/USD', 'XAG/USD', 'XPT/USD', 'XPD/USD', 'XAU/EUR', 'XAG/EUR',
  // Crypto
  'BTC/USD', 'ETH/USD', 'BTC/USDT', 'ETH/USDT', 'SOL/USD', 'XRP/USD', 'BNB/USD', 'ADA/USD',
  // Indices
  'US30', 'NAS100', 'SPX500', 'GER40', 'UK100', 'US500', 'US100', 'GER30',
  'JP225', 'AUS200', 'FRA40', 'ESP35', 'ITA40', 'HK50', 'VIX',
];

export const STRATEGY_SUGGESTIONS = [
  'Breakout', 'Trend Following', 'Support/Resistance Bounce',
  'Fibonacci Retracement', 'London Open Scalp', 'NY Session Momentum',
  'Pullback Entry', 'Range Reversal', 'Trendline Break',
  'Double Top/Bottom', 'Head & Shoulders', 'Moving Average Crossover',
  'RSI Divergence', 'Supply & Demand', 'Order Block', 'Liquidity Sweep',
];

export const BROKER_SUGGESTIONS = [
  'FTMO', 'MyForexFunds', 'The Funded Trader', 'IC Markets', 'Pepperstone',
  'OANDA', 'Darwinex', 'XM', 'Exness', 'FXTM', 'Blueberry Markets',
  'Axi', 'Vantage', 'City Index', 'Prop Firm Challenge',
];

export const LESSON_SUGGESTIONS = [
  'Patience pays off — waited for confirmation before entering',
  'Should have trusted my analysis and held the position longer',
  'Cut the trade too early out of fear, need to let winners run',
  'The trend was my friend today, sticking to the plan worked',
  'Overtraded during this session, need to stick to max 3 trades',
  'Great risk management today — only risked 1% and it paid off',
  'Chased the move after missing the initial entry, ended up with a loss',
  'News spike caught me off guard, always check the economic calendar',
  'Followed my rules perfectly today, this is the standard to maintain',
  'Let emotions get the better of me after a losing streak',
  'Perfect confluence setup — support + trendline + RSI divergence',
  'Should have waited for the retest instead of entering on the breakout',
  'Market structure was unclear, should have stayed on the sidelines',
  'Trailed my stop too tight and got stopped out before the move',
  'The higher timeframe bias saved me from taking a bad trade',
  'Risk-reward was too low, need at least 1:2 on every trade',
  'Entered too large a position size for the setup quality',
  'Discipline > predictions. Following the process is what matters',
];

export const NOTE_SUGGESTIONS = [
  'Clean breakout from the Asian range with strong London momentum. Volume confirmed the move.',
  'Price respected the 61.8% fib level perfectly. Entered with tight stop above structure.',
  'Failed breakout — price couldn\'t hold above the key level. Shorted the retest.',
  'Trend continuation trade on the H4 timeframe. Aligned with daily bias.',
  'Scalped the London open with tight spreads. Quick 15-pip grab.',
  'Range bound market today, took the reversal at the top of the range.',
  'Waited for the pullback to the 20 EMA before entering. Textbook setup.',
  'Strong fundamental data supported the move. Held through minor retracement.',
  'Market was choppy today, should have stayed out. Lesson learned.',
  'Perfect confluence: support level + trendline + RSI divergence. High conviction trade.',
  'Liquidity sweep below the previous low before the reversal. Smart money entry.',
  'Order block on H1 aligned with H4 trend. Patient entry paid off.',
];

export const GOAL_SUGGESTIONS = [
  'Take only A+ setups, max 3 trades per session',
  'Risk no more than 1% per trade',
  'No trading during high-impact news events',
  'Journal every trade with full details',
  'Wait for confirmation candle before entering',
  'Minimum 1:2 risk-reward ratio on all trades',
  'No revenge trading after a loss',
  'Review yesterday\'s trades before today\'s session',
  'Set daily max loss limit of 3%',
  'Take a break after 2 consecutive losses',
];

export const FOCUS_SUGGESTIONS = [
  'Patience — wait for confirmation before entering',
  'Risk management — stick to 1% risk per trade',
  'Discipline — follow the trading plan without exceptions',
  'Let winners run — don\'t cut profitable trades too early',
  'Avoid overtrading — quality over quantity',
  'Emotional control — don\'t let losses affect the next trade',
  'Process over outcome — focus on execution, not the result',
  'Preparation — review the daily chart before each session',
  'Consistency — trade the same way every day',
  'Position sizing — never risk more than planned',
];
