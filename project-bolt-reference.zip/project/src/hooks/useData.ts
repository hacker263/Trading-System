import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { Trade, TradeInput, JournalEntry, JournalInput, TraderProfile, TraderStrategy, TraderStrategyInput, StrategyChecklistItem, StrategyChecklistInput, RiskSettings, RiskSettingsInput, PreTradeChecklistItem, PreTradeChecklistInput } from '@/lib/types';

export function useTrades(userId?: string | null) {
  const [trades, setTrades] = useState<Trade[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchTrades = useCallback(async () => {
    setLoading(true);
    let query = supabase.from('trades').select('*').order('entry_time', { ascending: false });
    if (userId) query = query.eq('user_id', userId);
    const { data, error } = await query;
    if (error) {
      console.error('Failed to fetch trades:', error);
    } else {
      setTrades(data as Trade[]);
    }
    setLoading(false);
  }, [userId]);

  useEffect(() => {
    fetchTrades();
  }, [fetchTrades]);

  const addTrade = async (trade: TradeInput): Promise<Trade> => {
    const { data, error } = await supabase
      .from('trades')
      .insert(trade)
      .select()
      .single();
    if (error) throw error;
    await fetchTrades();
    return data as Trade;
  };

  const updateTrade = async (id: string, trade: Partial<TradeInput>): Promise<void> => {
    const { error } = await supabase
      .from('trades')
      .update(trade)
      .eq('id', id);
    if (error) throw error;
    await fetchTrades();
  };

  const deleteTrade = async (id: string): Promise<void> => {
    const { error } = await supabase
      .from('trades')
      .delete()
      .eq('id', id);
    if (error) throw error;
    await fetchTrades();
  };

  return { trades, loading, fetchTrades, addTrade, updateTrade, deleteTrade };
}

export function useJournalEntries(userId?: string | null) {
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchEntries = useCallback(async () => {
    setLoading(true);
    let query = supabase.from('journal_entries').select('*').order('entry_date', { ascending: false });
    if (userId) query = query.eq('user_id', userId);
    const { data, error } = await query;
    if (error) {
      console.error('Failed to fetch journal entries:', error);
    } else {
      setEntries(data as JournalEntry[]);
    }
    setLoading(false);
  }, [userId]);

  useEffect(() => {
    fetchEntries();
  }, [fetchEntries]);

  const upsertEntry = async (entry: JournalInput, id?: string): Promise<void> => {
    if (id) {
      const { error } = await supabase.from('journal_entries').update(entry).eq('id', id);
      if (error) throw error;
    } else {
      const { error } = await supabase.from('journal_entries').insert(entry);
      if (error) throw error;
    }
    await fetchEntries();
  };

  const deleteEntry = async (id: string): Promise<void> => {
    const { error } = await supabase.from('journal_entries').delete().eq('id', id);
    if (error) throw error;
    await fetchEntries();
  };

  return { entries, loading, fetchEntries, upsertEntry, deleteEntry };
}

export function useProfiles() {
  const [profiles, setProfiles] = useState<TraderProfile[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchProfiles = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('display_name', { ascending: true });
    if (error) {
      console.error('Failed to fetch profiles:', error);
    } else {
      setProfiles(data as TraderProfile[]);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchProfiles();
  }, [fetchProfiles]);

  return { profiles, loading, fetchProfiles };
}

export function useStrategies(userId?: string | null) {
  const [strategies, setStrategies] = useState<TraderStrategy[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchStrategies = useCallback(async () => {
    if (!userId) { setStrategies([]); setLoading(false); return; }
    setLoading(true);
    const { data, error } = await supabase
      .from('trader_strategies')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: true });
    if (error) {
      console.error('Failed to fetch strategies:', error);
    } else {
      setStrategies(data as TraderStrategy[]);
    }
    setLoading(false);
  }, [userId]);

  useEffect(() => {
    fetchStrategies();
  }, [fetchStrategies]);

  const addStrategy = async (strategy: TraderStrategyInput): Promise<TraderStrategy> => {
    const { data, error } = await supabase
      .from('trader_strategies')
      .insert(strategy)
      .select()
      .single();
    if (error) throw error;
    await fetchStrategies();
    return data as TraderStrategy;
  };

  const updateStrategy = async (id: string, updates: Partial<TraderStrategyInput>): Promise<void> => {
    const { error } = await supabase
      .from('trader_strategies')
      .update(updates)
      .eq('id', id);
    if (error) throw error;
    await fetchStrategies();
  };

  const deleteStrategy = async (id: string): Promise<void> => {
    const { error } = await supabase
      .from('trader_strategies')
      .delete()
      .eq('id', id);
    if (error) throw error;
    await fetchStrategies();
  };

  return { strategies, loading, fetchStrategies, addStrategy, updateStrategy, deleteStrategy };
}

export function useStrategyChecklist(strategyId?: string | null) {
  const [items, setItems] = useState<StrategyChecklistItem[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchItems = useCallback(async () => {
    if (!strategyId) { setItems([]); setLoading(false); return; }
    setLoading(true);
    const { data, error } = await supabase
      .from('strategy_checklist_items')
      .select('*')
      .eq('strategy_id', strategyId)
      .eq('is_active', true)
      .order('sort_order', { ascending: true });
    if (error) {
      console.error('Failed to fetch strategy checklist:', error);
    } else {
      setItems(data as StrategyChecklistItem[]);
    }
    setLoading(false);
  }, [strategyId]);

  useEffect(() => {
    fetchItems();
  }, [fetchItems]);

  const addItem = async (label: string, isRequired: boolean): Promise<void> => {
    if (!strategyId) return;
    const maxOrder = items.reduce((max, item) => Math.max(max, item.sort_order), -1);
    const { data, error } = await supabase
      .from('strategy_checklist_items')
      .insert({ strategy_id: strategyId, label, is_required: isRequired, sort_order: maxOrder + 1, is_active: true })
      .select()
      .single();
    if (error) throw error;
    setItems(prev => [...prev, data as StrategyChecklistItem]);
  };

  const updateItem = async (id: string, updates: Partial<StrategyChecklistInput>): Promise<void> => {
    const { error } = await supabase
      .from('strategy_checklist_items')
      .update(updates)
      .eq('id', id);
    if (error) throw error;
    await fetchItems();
  };

  const deleteItem = async (id: string): Promise<void> => {
    const { error } = await supabase
      .from('strategy_checklist_items')
      .delete()
      .eq('id', id);
    if (error) throw error;
    setItems(prev => prev.filter(item => item.id !== id));
  };

  const addBatch = async (newItems: { label: string; is_required: boolean }[]): Promise<void> => {
    if (!strategyId || newItems.length === 0) return;
    const maxOrder = items.reduce((max, item) => Math.max(max, item.sort_order), -1);
    const inserts = newItems.map((item, i) => ({
      strategy_id: strategyId,
      label: item.label,
      is_required: item.is_required,
      sort_order: maxOrder + 1 + i,
      is_active: true,
    }));
    const { data, error } = await supabase
      .from('strategy_checklist_items')
      .insert(inserts)
      .select()
      .order('sort_order', { ascending: true });
    if (error) throw error;
    if (data) setItems(data as StrategyChecklistItem[]);
  };

  return { items, loading, fetchItems, addItem, updateItem, deleteItem, addBatch };
}

const DEFAULT_CHECKLIST_ITEMS: { label: string; is_required: boolean; sort_order: number }[] = [
  { label: 'Higher timeframe trend confirmed', is_required: true, sort_order: 0 },
  { label: 'Key support/resistance level identified', is_required: true, sort_order: 1 },
  { label: 'Risk is under my per-trade limit', is_required: true, sort_order: 2 },
  { label: 'No major news within 30 minutes', is_required: false, sort_order: 3 },
  { label: 'Entry plan is clear (entry, SL, TP)', is_required: true, sort_order: 4 },
];

export function useRiskSettings(userId?: string | null) {
  const [settings, setSettings] = useState<RiskSettings | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchSettings = useCallback(async () => {
    if (!userId) { setSettings(null); setLoading(false); return; }
    setLoading(true);
    const { data, error } = await supabase
      .from('risk_settings')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();
    if (error) {
      console.error('Failed to fetch risk settings:', error);
    } else {
      setSettings(data as RiskSettings | null);
    }
    setLoading(false);
  }, [userId]);

  useEffect(() => {
    fetchSettings();
  }, [fetchSettings]);

  const saveSettings = async (input: RiskSettingsInput): Promise<RiskSettings> => {
    if (!userId) throw new Error('Not authenticated');
    const { data: existing } = await supabase
      .from('risk_settings')
      .select('id')
      .eq('user_id', userId)
      .maybeSingle();
    if (existing) {
      const { data, error } = await supabase
        .from('risk_settings')
        .update(input)
        .eq('id', existing.id)
        .select()
        .single();
      if (error) throw error;
      setSettings(data as RiskSettings);
      return data as RiskSettings;
    } else {
      const { data, error } = await supabase
        .from('risk_settings')
        .insert({ ...input, user_id: userId })
        .select()
        .single();
      if (error) throw error;
      setSettings(data as RiskSettings);
      return data as RiskSettings;
    }
  };

  return { settings, loading, fetchSettings, saveSettings };
}

export function useChecklist(userId?: string | null) {
  const [checklist, setChecklist] = useState<PreTradeChecklistItem[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchChecklist = useCallback(async () => {
    if (!userId) { setChecklist([]); setLoading(false); return; }
    setLoading(true);
    const { data, error } = await supabase
      .from('pre_trade_checklist')
      .select('*')
      .eq('user_id', userId)
      .eq('is_active', true)
      .order('sort_order', { ascending: true });
    if (error) {
      console.error('Failed to fetch checklist:', error);
    } else if (data && data.length === 0) {
      // Seed default checklist items
      const inserts = DEFAULT_CHECKLIST_ITEMS.map(item => ({ ...item, user_id: userId }));
      const { data: seeded, error: seedError } = await supabase
        .from('pre_trade_checklist')
        .insert(inserts)
        .select()
        .order('sort_order', { ascending: true });
      if (!seedError && seeded) {
        setChecklist(seeded as PreTradeChecklistItem[]);
      }
    } else {
      setChecklist(data as PreTradeChecklistItem[]);
    }
    setLoading(false);
  }, [userId]);

  useEffect(() => {
    fetchChecklist();
  }, [fetchChecklist]);

  const addChecklistItem = async (label: string, isRequired: boolean): Promise<void> => {
    if (!userId) return;
    const maxOrder = checklist.reduce((max, item) => Math.max(max, item.sort_order), -1);
    const { data, error } = await supabase
      .from('pre_trade_checklist')
      .insert({ user_id: userId, label, is_required: isRequired, sort_order: maxOrder + 1, is_active: true })
      .select()
      .single();
    if (error) throw error;
    setChecklist(prev => [...prev, data as PreTradeChecklistItem]);
  };

  const updateChecklistItem = async (id: string, updates: Partial<PreTradeChecklistInput>): Promise<void> => {
    const { error } = await supabase
      .from('pre_trade_checklist')
      .update(updates)
      .eq('id', id);
    if (error) throw error;
    await fetchChecklist();
  };

  const deleteChecklistItem = async (id: string): Promise<void> => {
    const { error } = await supabase
      .from('pre_trade_checklist')
      .delete()
      .eq('id', id);
    if (error) throw error;
    setChecklist(prev => prev.filter(item => item.id !== id));
  };

  return { checklist, loading, fetchChecklist, addChecklistItem, updateChecklistItem, deleteChecklistItem };
}
