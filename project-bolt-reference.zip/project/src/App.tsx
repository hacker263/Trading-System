import { useState, useEffect } from 'react';
import { ThemeProvider } from '@/context/ThemeContext';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { Layout, type PageId } from '@/components/Layout';
import { DashboardPage } from '@/pages/DashboardPage';
import { TradesPage } from '@/pages/TradesPage';
import { CalendarPage } from '@/pages/CalendarPage';
import { AnalyticsPage } from '@/pages/AnalyticsPage';
import { JournalPage } from '@/pages/JournalPage';
import { AIInsightsPage } from '@/pages/AIInsightsPage';
import { LeaderboardPage } from '@/pages/LeaderboardPage';
import { ComparePage } from '@/pages/ComparePage';
import { AuthPage } from '@/pages/AuthPage';
import { LandingPage } from '@/pages/LandingPage';
import { OnboardingPage } from '@/pages/OnboardingPage';
import { LoadingSpinner } from '@/components/ui/Feedback';
import { supabase } from '@/lib/supabase';

function AppContent() {
  const { session, loading } = useAuth();
  const [page, setPage] = useState<PageId>('dashboard');
  const [quickAdd, setQuickAdd] = useState(false);
  const [showLanding, setShowLanding] = useState(true);
  const [onboardingNeeded, setOnboardingNeeded] = useState<boolean | null>(null);

  useEffect(() => {
    if (!session?.user) {
      setOnboardingNeeded(null);
      return;
    }
    let cancelled = false;
    (async () => {
      const { count } = await supabase
        .from('trader_strategies')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', session.user.id);
      if (!cancelled) setOnboardingNeeded(count === 0);
    })();
    return () => { cancelled = true; };
  }, [session]);

  if (loading) {
    return (
      <div className="min-h-screen bg-primary flex items-center justify-center">
        <LoadingSpinner label="Loading..." />
      </div>
    );
  }

  if (showLanding) {
    return <LandingPage onEnter={() => setShowLanding(false)} />;
  }

  if (!session) {
    return <AuthPage onBack={() => setShowLanding(true)} />;
  }

  if (onboardingNeeded === null) {
    return (
      <div className="min-h-screen bg-primary flex items-center justify-center">
        <LoadingSpinner label="Preparing your journal..." />
      </div>
    );
  }

  if (onboardingNeeded) {
    return <OnboardingPage onComplete={() => setOnboardingNeeded(false)} />;
  }

  return (
    <Layout current={page} onNavigate={setPage} onQuickAdd={() => setQuickAdd(true)}>
      <div key={page} className="animate-fade-in">
        {page === 'dashboard' && <DashboardPage quickAdd={quickAdd} onQuickAddClose={() => setQuickAdd(false)} />}
        {page === 'trades' && <TradesPage quickAdd={quickAdd} onQuickAddClose={() => setQuickAdd(false)} />}
        {page === 'calendar' && <CalendarPage quickAdd={quickAdd} onQuickAddClose={() => setQuickAdd(false)} />}
        {page === 'analytics' && <AnalyticsPage />}
        {page === 'journal' && <JournalPage />}
        {page === 'ai' && <AIInsightsPage />}
        {page === 'leaderboard' && <LeaderboardPage />}
        {page === 'compare' && <ComparePage />}
      </div>
    </Layout>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
